package com.vietfintex.marketplace.webapp.controller;

import com.vietfintex.marketplace.web.dto.ProductDTO;
import com.vietfintex.marketplace.webapp.model.CartModel;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/cart")
public class CartController extends CommonWebController {
    @RequestMapping("/add/{productId}/{qty}/")
    public String add(@PathVariable("productId") Long productId, @PathVariable("qty") int qty) {
        CartModel cart = this.getCart();
        ProductDTO product = productService.getProductById(productId);
        if (product != null) {
            cart.addItem(product, qty);
            this.httpSession.setAttribute("cart", cart);
        }
        return "redirect:/cart/";
    }

    @RequestMapping("/remove/{productId}/")
    public String remove(@PathVariable("productId") Long productId) {
        CartModel cart = this.getCart();
        cart.removeItem(productId);
        return "redirect:/cart/";
    }

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String view(ModelMap model) {
        super.view(model);

        model.addAttribute("_view", "cart");
        return "main";
    }
}