package com.vietfintex.marketplace.webapp.model;

import com.vietfintex.marketplace.web.dto.ProductDTO;

public class ProductModel {
    private ProductDTO productDTO;

    private String avatar;


}
