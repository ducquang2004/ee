package com.vietfintex.marketplace.webapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/article")
public class ArticleController extends CommonWebController {
    @RequestMapping(method = RequestMethod.GET)
    public String view(ModelMap model) {
        super.view(model);

        model.addAttribute("treeCategory", treeCategory);
        model.addAttribute("_view", "article-detail");
        return "main";
    }
}