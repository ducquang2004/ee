package com.vietfintex.marketplace.webapp.controller;

import com.vietfintex.marketplace.web.dto.AdvertisementDTO;
import com.vietfintex.marketplace.web.dto.ProductDTO;
import com.vietfintex.marketplace.web.service.AdvertisementService;
import com.vietfintex.marketplace.webapp.model.CategoryModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
@RequestMapping("/")
public class HomeController extends CommonWebController {
    @Autowired
    AdvertisementService advertisementService;

    @RequestMapping(method = RequestMethod.GET)
    public String view(ModelMap model) {
        super.view(model);

        // Product
        for (CategoryModel item : listCategory) {
            if (item.getCategoryDTO().getFeatured() == 1) {
                item.setProducts(this.getProductByCategory(item.getCategoryDTO().getCategoryId()));
            }
        }
        List<ProductDTO> topProducts = productService.getTopProduct();

        // Ads
        List<AdvertisementDTO> ads = advertisementService.getAdvertisement();

        model.addAttribute("listCategory", listCategory);
        model.addAttribute("treeCategoryCount", treeCategory.size());
        model.addAttribute("topProducts", topProducts);
        model.addAttribute("ads", ads);
        model.addAttribute("_view", "home");
        return "main";
    }
}