package com.vietfintex.marketplace.webapp.controller;

import com.vietfintex.marketplace.webapp.model.CategoryModel;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/category")
public class CategoryWebController extends CommonWebController {
    @RequestMapping("/{aliasName}")
    public String view(ModelMap model, @PathVariable("aliasName") String aliasName) {
        super.view(model);

        CategoryModel category = null;

        for (CategoryModel item : listCategory) {
            if (item.categoryDTO.getAliasName().equals(aliasName)) {
                category = item;
            }
        }

        if (category != null) {
            category.setProducts(this.getProductByCategory(category.categoryDTO.getCategoryId()));
            model.addAttribute("category", category);
            model.addAttribute("_title", category.getCategoryDTO().getCategoryName());
            model.addAttribute("_view", "category");
        } else {
            model.addAttribute("_title", "Không tìm thấy trang!");
            model.addAttribute("_view", "error-404");
        }
        return "main";
    }
}
