package com.vietfintex.marketplace.webapp.controller;

import com.vietfintex.marketplace.web.dto.ProductDTO;
import com.vietfintex.marketplace.web.dto.ProductFeatureDTO;
import com.vietfintex.marketplace.web.dto.ProductOptionMDTO;
import com.vietfintex.marketplace.web.service.ProductFeatureService;
import com.vietfintex.marketplace.web.service.ProductOptionMService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/product")
public class ProductWebController extends CommonWebController {
    @Autowired
    ProductFeatureService productFeatureService;
    @Autowired
    private ProductOptionMService productOptionMService;

    @RequestMapping("/{id}/")
    public String view(ModelMap model, @PathVariable("id") Long id) {
        super.view(model);

        ProductDTO product = productService.getProductById(id);

        if (product != null) {
            List<ProductDTO> relateProducts = this.getProductByCategory(product.getCategoryId());
            if (relateProducts != null) {
                for (int i = relateProducts.size() - 1; i >= 0; i--) {
                    if (relateProducts.get(i).getProductId().equals(product.getProductId())) {
                        relateProducts.remove(i);
                    }
                }
                if (relateProducts.size() == 0) {
                    relateProducts = null;
                }
            }
            model.addAttribute("relateProducts", relateProducts);

            List<ProductFeatureDTO> listFeatures = productFeatureService.getProductFeature(id);
            if (listFeatures != null && listFeatures.size() == 0) {
                listFeatures = null;
            }
            model.addAttribute("listFeatureSize", listFeatures != null ? listFeatures.size() : 0);
            model.addAttribute("listFeatures", listFeatures);

            List<ProductOptionMDTO> listOptions = productOptionMService.getByProductId(id);
            if (listOptions != null && listOptions.size() == 0) {
                listOptions = null;
            }
            model.addAttribute("listOptions", listOptions);
            model.addAttribute("listOptionSize", listOptions != null ? listOptions.size() : 0);


            model.addAttribute("product", product);
            model.addAttribute("_title", product.getProductName());
            model.addAttribute("_view", "product");
        } else {
            model.addAttribute("_title", "Không tìm thấy trang!");
            model.addAttribute("_view", "error-404");
        }
        return "main";
    }
}