package com.vietfintex.marketplace.webapp.model;

import com.vietfintex.marketplace.web.dto.ProductDTO;

public class CartItemModel {
    private ProductDTO productDTO;
    private int qty;

    public CartItemModel(ProductDTO productDTO, int qty) {
        this.productDTO = productDTO;
        this.qty = qty;
    }

    public ProductDTO getProductDTO() {
        return productDTO;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }
}
