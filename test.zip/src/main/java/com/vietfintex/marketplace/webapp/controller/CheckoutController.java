package com.vietfintex.marketplace.webapp.controller;

import com.vietfintex.marketplace.web.dto.OrderDTO;
import com.vietfintex.marketplace.web.dto.OrderWrapDTO;
import com.vietfintex.marketplace.web.dto.ProductDTO;
import com.vietfintex.marketplace.web.dto.UserDTO;
import com.vietfintex.marketplace.web.service.OrderService;
import com.vietfintex.marketplace.webapp.model.CartItemModel;
import com.vietfintex.marketplace.webapp.model.CartModel;
import com.vietfintex.marketplace.webapp.model.ProductModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/checkout")
public class CheckoutController extends CommonWebController {
    @Autowired
    OrderService orderService;

    @RequestMapping(method = RequestMethod.GET)
    public String view(ModelMap model) {
        super.view(model);
        return this.loadView(model);
    }

    @RequestMapping(method = RequestMethod.POST)
    public String order(ModelMap model) {
        super.view(model);
        UserDTO user = this.getUser();
        if (user == null) {
            return "redirect:/login";
        }
        CartModel cart = this.getCart();
        if (cart == null || cart.getTotalItems() == 0) {
            return "redirect:/";
        }
        OrderWrapDTO orderWrapDTO = new OrderWrapDTO();
        orderWrapDTO.setUserId(user.getUserId());
        orderWrapDTO.setDeliveryPlaceId((long) 8);
        orderWrapDTO.setStatusId((long) 1);
        List<ProductDTO> listProductDTO = new ArrayList<>();
        List<Integer> listQty = new ArrayList<>();
        for (CartItemModel cartItemModel : cart.getItems()) {
            listProductDTO.add(cartItemModel.getProductDTO());
            listQty.add(cartItemModel.getQty());
        }
        orderWrapDTO.setProductDTOList(listProductDTO);
        orderWrapDTO.setQuantity(listQty);
        List<OrderDTO> returnData = orderService.takeOrder(orderWrapDTO);
        if (returnData != null){
            model.addAttribute("success", true);
            model.addAttribute("redirectTo", "/");
            model.addAttribute("redirectToTimeout", 5);
        } else {
            model.addAttribute("success", false);
        }
        return this.loadView(model);
    }

    private String loadView(ModelMap model) {
        CartModel cart = this.getCart();
        if (cart == null || cart.getTotalItems() == 0) {
            return "redirect:/";
        }
        if (this.getUser() == null) {
            this.setFlashData("loginRedirectTo", "/checkout");
        }
        model.addAttribute("_view", "checkout");
        return "main";
    }
}