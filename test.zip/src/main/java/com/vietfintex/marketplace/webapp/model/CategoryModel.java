package com.vietfintex.marketplace.webapp.model;

import com.vietfintex.marketplace.web.dto.CategoryDTO;
import com.vietfintex.marketplace.web.dto.ProductDTO;

import java.util.ArrayList;
import java.util.List;

public class CategoryModel {

    public CategoryDTO categoryDTO;
    public List<CategoryModel> childs = new ArrayList<>();
    public List<ProductDTO> products = new ArrayList<>();
    public String url = "";
    private String avatar;

    public CategoryModel(CategoryDTO categoryDTO) {
        this.categoryDTO = categoryDTO;
        this.setUrl("/category/" + this.categoryDTO.getAliasName() + "/");
    }

    public CategoryDTO getCategoryDTO() {
        return this.categoryDTO;
    }

    public void setCategoryDTO(CategoryDTO categoryDTO) {
        this.categoryDTO = categoryDTO;
    }

    public List<CategoryModel> getChilds() {
        return childs;
    }

    public void setChilds(List<CategoryModel> childs) {
        this.childs = childs;
    }

    public int getTotalChild() {
        return this.childs.size();
    }

    public void setProducts(List<ProductDTO> products) {
        this.products = products;
    }

    public List<ProductDTO> getProducts() {
        return products;
    }

    public int getTotalProduct() {
        return this.products.size();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }
}
