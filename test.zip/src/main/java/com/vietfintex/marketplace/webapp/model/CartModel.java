package com.vietfintex.marketplace.webapp.model;

import com.vietfintex.marketplace.web.dto.ProductDTO;

import java.util.ArrayList;
import java.util.List;

public class CartModel {
    private List<CartItemModel> items = new ArrayList<>();
    private int total = 0;

    private void calculateTotal() {
        total = 0;
        for (CartItemModel item : items) {
            total += (int) ((double) item.getProductDTO().getPrice()) * item.getQty();
        }
    }

    public void addItem(ProductDTO productDTO, int qty) {
        for (CartItemModel item : items) {
            if (item.getProductDTO().getProductId().equals(productDTO.getProductId())) {
                item.setQty(item.getQty() + qty);
                this.calculateTotal();
                return;
            }
        }
        CartItemModel cartItemModel = new CartItemModel(productDTO, qty);
        items.add(cartItemModel);
        this.calculateTotal();
    }

    public void removeItem(Long productId) {
        for (int i = items.size() - 1; i >= 0; i--) {
            if (items.get(i).getProductDTO().getProductId().equals(productId)) {
                items.remove(i);
            }
        }
        this.calculateTotal();
    }

    public List<CartItemModel> getItems() {
        return items;
    }

    public int getTotalItems() {
        return items.size();
    }

    public int getTotal() {
        return total;
    }
}
