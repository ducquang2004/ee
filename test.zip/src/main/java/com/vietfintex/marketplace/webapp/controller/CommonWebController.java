package com.vietfintex.marketplace.webapp.controller;

import com.vietfintex.marketplace.web.dto.CategoryDTO;
import com.vietfintex.marketplace.web.dto.ProductDTO;
import com.vietfintex.marketplace.web.dto.UserDTO;
import com.vietfintex.marketplace.web.service.CategoryService;
import com.vietfintex.marketplace.web.service.ProductService;
import com.vietfintex.marketplace.webapp.model.CartModel;
import com.vietfintex.marketplace.webapp.model.CategoryModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.ui.ModelMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

public class CommonWebController {
    @Autowired
    protected CategoryService categoryService;
    @Autowired
    protected ProductService productService;
    @Autowired
    protected HttpSession httpSession;
    @Autowired
    protected HttpServletRequest httpServletRequest;

    protected List<CategoryModel> listCategory;
    protected List<CategoryModel> treeCategory;

    protected void fetchCategories() {
        List<CategoryDTO> returnObject = categoryService.getCategoryList();

        this.listCategory = new ArrayList<>();
        for (CategoryDTO item : returnObject) {
            CategoryModel m = new CategoryModel(item);
            listCategory.add(m);
        }

        this.treeCategory = new ArrayList<>();
        for (CategoryModel item : listCategory) {
            if (item.categoryDTO.getParentCategoryId() <= 0) {
                treeCategory.add(this.fetchCategoryRecursive(item, listCategory, 0));
            }
        }
    }

    protected CategoryModel fetchCategoryRecursive(CategoryModel categoryModel,
                                                   List<CategoryModel> listCategory,
                                                   int deep) {
        if (deep > 5) {
            return categoryModel;
        }
        for (CategoryModel item : listCategory) {
            if (categoryModel.categoryDTO.getCategoryId().equals(item.categoryDTO.getParentCategoryId())) {
                categoryModel.childs.add(this.fetchCategoryRecursive(item, listCategory, deep + 1));
            }
        }
        return categoryModel;
    }

    protected List<ProductDTO> getProductByCategory(Long categoryId) {
        ProductDTO searchDTO = new ProductDTO();
        searchDTO.setCategoryId(categoryId);
        PageRequest p = new PageRequest(1, 10);
        try {
            return productService.search(searchDTO, p);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    protected CartModel getCart() {
        if (this.httpSession.getAttribute("cart") != null) {
            return (CartModel) httpSession.getAttribute("cart");
        }
        CartModel cartModel = new CartModel();
        this.httpSession.setAttribute("cart", cartModel);
        return cartModel;
    }

    protected UserDTO getUser() {
        if (this.httpSession.getAttribute("user") != null) {
            return (UserDTO) httpSession.getAttribute("user");
        }
        return null;
    }

    protected void setFlashData(String key, Object o) {
        this.httpSession.setAttribute(key, o);
    }

    protected boolean checkFlashData(String key) {
        return this.httpSession.getAttribute(key) != null;
    }

    protected Object getFlashData(String key) {
        Object o = this.httpSession.getAttribute(key);
        this.httpSession.removeAttribute(key);
        return o;
    }

    protected String getImageBaseUrl() {
        if (this.httpServletRequest.getRequestURL().indexOf("localhost") >= 0) {
            return "http://eplaza.vn";
        }
        return "";
    }

    public String view(ModelMap model) {
        this.fetchCategories();
        model.addAttribute("_title", "ePlaza");
        model.addAttribute("_imageBaseUrl", this.getImageBaseUrl());
        model.addAttribute("cart", this.getCart());
        model.addAttribute("user", this.getUser());
        model.addAttribute("treeCategory", treeCategory);
        return "";
    }
}
