package com.vietfintex.marketplace.webapp.controller;

import com.vietfintex.marketplace.web.dto.UserDTO;
import com.vietfintex.marketplace.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/register")
public class RegisterController extends CommonWebController {
    @Autowired
    private UserService userService;

    @RequestMapping(method = RequestMethod.GET)
    public String view(ModelMap model) {
        return this.loadView(model);
    }

    @RequestMapping(method = RequestMethod.POST)
    public String register(ModelMap model) {
        String firstName = this.httpServletRequest.getParameter("firstName");
        String lastName = this.httpServletRequest.getParameter("lastName");
        String email = this.httpServletRequest.getParameter("email");
        String phone = this.httpServletRequest.getParameter("phone");
        String username = this.httpServletRequest.getParameter("username");
        String password = this.httpServletRequest.getParameter("password");
        String repassword = this.httpServletRequest.getParameter("repassword");
        if (firstName == null || lastName == null || username == null || password == null || repassword == null) {
            model.addAttribute("error", "Vui lòng nhập đủ các thông tin!");
        } else {
            UserDTO user = new UserDTO();
            user.setFirstname(firstName);
            user.setLastname(lastName);
            user.setEmail(email);
            user.setPhone(phone);
            user.setUserName(username);
            user.setPassword(password);
            user.setStatus("A");
            user.setSex("1");
            user.setUserType("C");
            try {
                userService.validate(user);
                UserDTO checkUser = userService.checkUser(user.getUserName() != null ?
                        user.getUserName() : "", user.getEmail() != null ?
                        user.getEmail() : "", user.getPhone() != null ?
                        user.getPhone() : "");
                if (checkUser == null) {
                    userService.register(user);
                    model.addAttribute("success", true);
                } else {
                    String msg = "";
                    if (user.getUserName() != null && user.getUserName().equals(checkUser.getUserName())) {
                        msg += "Tên đăng nhập đã được sử dụng";
                    }
                    if (user.getEmail() != null && user.getEmail().equals(checkUser.getEmail())) {
                        msg += "\nEmail đã được sử dụng";
                    }
                    if (user.getPhone() != null && user.getPhone().equals(checkUser.getPhone())) {
                        msg += "\nSố điện thoại đã được sử dụng";
                    }
                    model.addAttribute("error", msg);
                }
            } catch (Exception e) {
                e.printStackTrace();
                model.addAttribute("error", "Có lỗi xảy ra: " + e.getMessage());
            }
        }
        return this.loadView(model);
    }

    private String loadView(ModelMap model) {
        super.view(model);
        model.addAttribute("_view", "register");
        return "main";
    }
}