package com.vietfintex.marketplace.webapp.controller;

import com.vietfintex.marketplace.web.dto.UserDTO;
import com.vietfintex.marketplace.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/login")
public class LoginController extends CommonWebController {
    @Autowired
    private UserService userService;

    @RequestMapping(method = RequestMethod.GET)
    public String view(ModelMap model) {
        return this.loadView(model);
    }

    @RequestMapping(method = RequestMethod.POST)
    public String login(ModelMap model) {
        String username = this.httpServletRequest.getParameter("username");
        String password = this.httpServletRequest.getParameter("password");
        if (username == null || password == null) {
            model.addAttribute("error", "Vui lòng nhập đủ các thông tin!");
        } else {
            UserDTO userDTO = userService.login(username, password);
            if (userDTO == null) {
                model.addAttribute("error", "Sai tên đăng nhập hoặc mật khẩu!");
                this.httpSession.setAttribute("user", null);
            } else {
                if (this.checkFlashData("loginRedirectTo")) {
                    model.addAttribute("redirectTo", this.getFlashData("loginRedirectTo"));
                } else {
                    model.addAttribute("redirectTo", "/");
                }
                model.addAttribute("redirectToTimeout", 1);
                model.addAttribute("success", true);
                this.httpSession.setAttribute("user", userDTO);
            }
        }
        return this.loadView(model);
    }


    private String loadView(ModelMap model) {
        super.view(model);
        model.addAttribute("treeCategory", treeCategory);
        model.addAttribute("_view", "login");
        return "main";
    }
}