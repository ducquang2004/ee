package com.vietfintex.marketplace.constant;

public class CommonConstant {
	public static String PRODUCT_TYPE = "PRO";
	public static String GROUP_POST_TYPE = "GRO";
}
