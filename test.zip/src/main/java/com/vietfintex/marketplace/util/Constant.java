package com.vietfintex.marketplace.util;

public class Constant {
    static public String productImg = "PRO";
    static public String storeImg = "STO";
}
