package com.vietfintex.marketplace.web.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ObjectRequestDTO  implements Serializable {
    private static final long serialVersionUID = 1L;

}
