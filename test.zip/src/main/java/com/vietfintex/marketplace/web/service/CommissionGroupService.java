package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.CommissionGroup;
import com.vietfintex.marketplace.web.dto.CommissionGroupDTO;

public interface CommissionGroupService extends IOperations<CommissionGroup,CommissionGroupDTO> {
    CommissionGroupDTO getByGroupId(Long groupId);
    CommissionGroupDTO insertOrUpdate(CommissionGroupDTO commissionGroupDTO);
    CommissionGroupDTO getById(Long id);
}
