package com.vietfintex.marketplace.web.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CommissionGroupDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long commissionGroupId;
    private Long groupId;
    private Double ownerGroupPercent;
    private Long parentBuyerPercent;
    private Long buyerPercent;
    private Double smileTechPercent;

    public Long getCommissionGroupId() {
        return commissionGroupId;
    }

    public void setCommissionGroupId(Long commissionGroupId) {
        this.commissionGroupId = commissionGroupId;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public Double getOwnerGroupPercent() {
        return ownerGroupPercent;
    }

    public void setOwnerGroupPercent(Double ownerGroupPercent) {
        this.ownerGroupPercent = ownerGroupPercent;
    }

    public Long getParentBuyerPercent() {
        return parentBuyerPercent;
    }

    public void setParentBuyerPercent(Long parentBuyerPercent) {
        this.parentBuyerPercent = parentBuyerPercent;
    }

    public Long getBuyerPercent() {
        return buyerPercent;
    }

    public void setBuyerPercent(Long buyerPercent) {
        this.buyerPercent = buyerPercent;
    }

    public Double getSmileTechPercent() {
        return smileTechPercent;
    }

    public void setSmileTechPercent(Double smileTechPercent) {
        this.smileTechPercent = smileTechPercent;
    }
}
