package com.vietfintex.marketplace.web.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class OrderDetailWrapDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long itemId;
    private Long orderId;
    private Long productId;
    private String productCode;
    private Double price;
    private Double listPrice;
    private Integer quantity;
    private Long deliverPlaceId;
    private Date createTime;
    private Date deliveredTime;
    private Date expectedDeliveryTime;
    private Long deliveryStatus;
    private Double shippingCost;
    private String remark;
    private Long userId;
    private List<ImageLinkDTO> imageLinkDTOList;

    private String productName;
    private Long storeId;
    private ProductOptionMDTO productOption;
    private Long productOptionId;

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getListPrice() {
        return listPrice;
    }

    public void setListPrice(Double listPrice) {
        this.listPrice = listPrice;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Long getDeliverPlaceId() {
        return deliverPlaceId;
    }

    public void setDeliverPlaceId(Long deliverPlaceId) {
        this.deliverPlaceId = deliverPlaceId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getDeliveredTime() {
        return deliveredTime;
    }

    public void setDeliveredTime(Date deliveredTime) {
        this.deliveredTime = deliveredTime;
    }

    public Date getExpectedDeliveryTime() {
        return expectedDeliveryTime;
    }

    public void setExpectedDeliveryTime(Date expectedDeliveryTime) {
        this.expectedDeliveryTime = expectedDeliveryTime;
    }

    public Long getDeliveryStatus() {
        return deliveryStatus;
    }

    public void setDeliveryStatus(Long deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    public Double getShippingCost() {
        return shippingCost;
    }

    public void setShippingCost(Double shippingCost) {
        this.shippingCost = shippingCost;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    public List<ImageLinkDTO> getImageLinkDTOList() {
        return imageLinkDTOList;
    }

    public void setImageLinkDTOList(List<ImageLinkDTO> imageLinkDTOList) {
        this.imageLinkDTOList = imageLinkDTOList;
    }

    public ProductOptionMDTO getProductOption() {
        return productOption;
    }

    public void setProductOption(ProductOptionMDTO productOption) {
        this.productOption = productOption;
    }

    public Long getProductOptionId() {
        return productOptionId;
    }

    public void setProductOptionId(Long productOptionId) {
        this.productOptionId = productOptionId;
    }
}
