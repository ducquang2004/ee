package com.vietfintex.marketplace.web.controller;

import com.vietfintex.marketplace.web.dto.AdvertisementDTO;
import com.vietfintex.marketplace.web.dto.ResponseDTO;
import com.vietfintex.marketplace.web.service.AdvertisementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/advertisement")
public class AdvertisementController {
    @Autowired
    AdvertisementService advertisementService;

    @GetMapping("/getAdvertisement")
    @ResponseBody
    public ResponseDTO getAdvertisement(){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            List<AdvertisementDTO> returnObject = advertisementService.getAdvertisement();
            if (returnObject != null){
                responseDTO.setObjectReturn(returnObject);
                responseDTO.setSuccess(true);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+ e.getMessage());
        }
        return responseDTO;
    }
}
