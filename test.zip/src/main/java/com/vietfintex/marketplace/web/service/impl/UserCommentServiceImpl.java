package com.vietfintex.marketplace.web.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import com.vietfintex.marketplace.persistence.model.UserComment;
import com.vietfintex.marketplace.persistence.repo.UserCommentRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.UserCommentDTO;
import com.vietfintex.marketplace.web.service.UserCommentService;

@Service
public class UserCommentServiceImpl extends AbstractService<UserComment,UserCommentDTO> implements UserCommentService {
    @Autowired
    UserCommentRepo repo;
    private static final BaseMapper<UserComment, UserCommentDTO> mapper = new BaseMapper<>(UserComment.class,
            UserCommentDTO.class);

    @Override
    protected PagingAndSortingRepository<UserComment, Long> getDao() {
        return repo;
    }

    @Override
    protected BaseMapper<UserComment, UserCommentDTO> getMapper() {
        return mapper;
    }
}
