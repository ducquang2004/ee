package com.vietfintex.marketplace.web.service.impl;

import com.vietfintex.marketplace.persistence.model.GlobalFeature;
import com.vietfintex.marketplace.persistence.repo.GlobalFeatureRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.GlobalFeatueDTO;
import com.vietfintex.marketplace.web.service.GlobalFeatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GlobalFeatureServiceImpl extends AbstractService<GlobalFeature, GlobalFeatueDTO> implements GlobalFeatureService {

    private static final BaseMapper<GlobalFeature,GlobalFeatueDTO> mapper = new BaseMapper<>(GlobalFeature.class,GlobalFeatueDTO.class);
    @Autowired
    private GlobalFeatureRepo repo;

    @Override
    public List<GlobalFeatueDTO> getGlobalFeatureByCategory(Long categoryId) {
        List<Long> idList = repo.getParentCategory(categoryId);
        return getMapper().toDtoBean(repo.findAllByCategoryIdIn(idList));
    }

    @Override
    protected PagingAndSortingRepository<GlobalFeature, Long> getDao() {
        return repo;
    }

    @Override
    protected BaseMapper<GlobalFeature, GlobalFeatueDTO> getMapper() {
        return mapper;
    }
}
