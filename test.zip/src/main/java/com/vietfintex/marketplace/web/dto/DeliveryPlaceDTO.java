package com.vietfintex.marketplace.web.dto;

import java.io.Serializable;

public class DeliveryPlaceDTO extends ObjectRequestDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Long deliveryPlaceId;
    private Long userId;
    private String address;
    private Double longitude;
    private Double latitude;
    private String remark;
    private String contactPhone;
    private String contactName;

    public Long getDeliveryPlaceId() {
        return deliveryPlaceId;
    }

    public void setDeliveryPlaceId(Long deliveryPlaceId) {
        this.deliveryPlaceId = deliveryPlaceId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }
}
