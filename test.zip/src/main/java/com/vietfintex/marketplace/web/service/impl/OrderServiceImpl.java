package com.vietfintex.marketplace.web.service.impl;

import com.vietfintex.marketplace.persistence.model.Order;
import com.vietfintex.marketplace.persistence.model.OrderDetail;
import com.vietfintex.marketplace.persistence.model.ProductOptionM;
import com.vietfintex.marketplace.persistence.repo.OrderDetailRepo;
import com.vietfintex.marketplace.persistence.repo.OrderRepo;
import com.vietfintex.marketplace.persistence.repo.ProductOptionMRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.*;
import com.vietfintex.marketplace.web.service.DivisionService;
import com.vietfintex.marketplace.web.service.OrderDetailService;
import com.vietfintex.marketplace.web.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

@Service
public class OrderServiceImpl extends AbstractService<Order, OrderDTO> implements OrderService {
    private static final BaseMapper<Order, OrderDTO> mapper = new BaseMapper<>(Order.class, OrderDTO.class);
    private static final BaseMapper<OrderDetail, OrderDetailDTO> detailMapper = new BaseMapper<>(OrderDetail.class, OrderDetailDTO.class);
    @Autowired
    private OrderRepo orderRepo;
    @Autowired
    private OrderDetailRepo orderDetailRepo;

    @Autowired
    private ProductOptionMRepo productOptionMRepo;

    @Autowired
    DivisionService divisionService;

    @Autowired
    OrderDetailService orderDetailService;

    @Override
    protected PagingAndSortingRepository<Order, Long> getDao() {
        return orderRepo;
    }

    @Override
    protected BaseMapper<Order, OrderDTO> getMapper() {
        return mapper;
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public OrderDTO save(OrderDTO orderDTO) throws Exception {
        OrderDTO rs = getMapper().toDtoBean(getDao().save(getMapper().toPersistenceBean(orderDTO)));
//        List<OrderDetailDTO> optionVariantList = Optional.ofNullable(orderDTO.getOrderDetailList())
//                .orElseGet(ArrayList::new);
//        if (!optionVariantList.isEmpty()) {
//            orderDetailRepo.saveAll(detailMapper.toPersistenceBean(orderDTO.getOrderDetailList()));
//        }
        return rs;
    }

    @Override
    public List<OrderDTO> search(OrderDTO searchDTO, Pageable pageable) throws Exception {
        return orderRepo.search(searchDTO, pageable);
    }

    @Override
    public Long count(OrderDTO searchDTO) {
        return orderRepo.count(searchDTO);
    }

    @Transactional
    @Override
    public List<OrderDTO> takeOrder(OrderWrapDTO orderWrapDTO) {
        if (orderWrapDTO.getProductDTOList().size() != orderWrapDTO.getQuantity().size()){
            return null;
        }
        List<OrderDTO> returnData = new ArrayList<>();
        HashMap<Long,List<ProductDTO>> orderData = new HashMap<>();
        HashMap<Long,Integer> quantityData = new HashMap<>();
        for (int i =0; i < orderWrapDTO.getProductDTOList().size();i++){
            ProductDTO productDTO = orderWrapDTO.getProductDTOList().get(i);
            quantityData.put(productDTO.getProductId(),orderWrapDTO.getQuantity().get(i));
            Long key = productDTO.getStoreId();
            List<ProductDTO> productDTOList = new ArrayList<>();
            if (orderData.containsKey(key)){
                productDTOList = orderData.get(key);
            }
            productDTOList.add(productDTO);
            orderData.put(key, productDTOList);
        }
        for (Long key : orderData.keySet()){
            //Them order theo cua hang
            Order order = new Order();
            order.setCreatedTime(Calendar.getInstance().getTime());
            order.setStoreId(key);
            order.setUserId(orderWrapDTO.getUserId());
            order.setDeliveryPlaceId(orderWrapDTO.getDeliveryPlaceId());
            order.setDeliveredTime(orderWrapDTO.getDeliveredTime());
            order.setExpectedDeliveryTime(orderWrapDTO.getExpectedDeliveryTime());
            order.setRemark(orderWrapDTO.getRemark());

            order = orderRepo.save(order);
            returnData.add(getMapper().toDtoBean(order));
            //order product
            List<ProductDTO> productDTOList = orderData.get(key);
            for (ProductDTO productDTO : productDTOList){
                OrderDetail orderDetail = new OrderDetail();
                orderDetail.setOrderId(order.getOrderId());
                orderDetail.setProductId(productDTO.getProductId());
                orderDetail.setProductCode(productDTO.getProductCode());
                orderDetail.setPrice(productDTO.getPrice() == null ? 0.0 : productDTO.getPrice());
                if (productDTO.getProductOptionId() != null) {
                    orderDetail.setProductOptionId(productDTO.getProductOptionId());
                    ProductOptionM optionM = productOptionMRepo.findById(productDTO.getProductOptionId()).orElse(null);
                    if (optionM != null && optionM.getProductId() == productDTO.getProductId()){
                        //Neu product option cd product Id khac product ID truyen vao tuc la k hop le.
                        //Lay thong tin gia cua product. bo qua option
                        orderDetail.setListPrice(optionM.getProductPrice());
                    }else{
                        orderDetail.setListPrice(productDTO.getListPrice());
                    }
                }else
                    orderDetail.setListPrice(productDTO.getListPrice());
                orderDetail.setQuantity(quantityData.get(productDTO.getProductId()));
                orderDetail.setUserId(orderWrapDTO.getUserId());
                orderDetail.setDeliverPlaceId(orderWrapDTO.getDeliveryPlaceId());
                orderDetail.setDeliveryStatus(1); //Them moi status phai o trang thai dang cho xu ly
                orderDetailRepo.save(orderDetail);
            }
        }
        return returnData;
    }

    @Override
    public List<OrderDetailWrapDTO> getOrderListByUserId(Long userId,Long deliveryStatus, int startResult, Long productOwnerId) {
        return  orderDetailRepo.getOrderByUserId(userId,deliveryStatus, startResult,productOwnerId);
    }

    //Ham nay được sử dụng khi cập nhận trạng thái đã xác nhận hoặc từ chối đơn hàng
    @Override
    public OrderDetailDTO updateOrderStatus(OrderDetailDTO orderDetailDTO) {
        return orderDetailService.updateStatus(orderDetailDTO);
    }

    @Override
    public OrderDetailDTO assignToTransport(OrderDetailDTO orderDetailDTO) {
        return orderDetailService.assignToTransport(orderDetailDTO);
    }

    @Override
    public OrderDetailDTO completeOrder(OrderDetailDTO orderDetailDTO) {
        return orderDetailService.completeOrder(orderDetailDTO);
    }
}
