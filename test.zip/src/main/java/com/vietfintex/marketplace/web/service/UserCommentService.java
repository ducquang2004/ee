package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.UserComment;
import com.vietfintex.marketplace.web.dto.UserCommentDTO;

public interface UserCommentService extends IOperations<UserComment,UserCommentDTO> {
}
