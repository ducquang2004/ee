package com.vietfintex.marketplace.web.controller;

import com.vietfintex.marketplace.web.dto.ProductOptionMDTO;
import com.vietfintex.marketplace.web.dto.ResponseDTO;
import com.vietfintex.marketplace.web.service.ProductOptionMService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/productOptions")
public class ProductOptionMController {
    @Autowired
    private ProductOptionMService productOptionMService;

    @GetMapping(value = "/getByProductId/{productId}")
    @ResponseBody
    public ResponseDTO getByProductId(@PathVariable("productId") Long productId ){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            List<ProductOptionMDTO> returnObject = productOptionMService.getByProductId(productId);
            if (returnObject != null){
                responseDTO.setSuccess(true);
                responseDTO.setObjectReturn(returnObject);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co lo xay ra "+e.toString());
        }
        return responseDTO;
    }
}
