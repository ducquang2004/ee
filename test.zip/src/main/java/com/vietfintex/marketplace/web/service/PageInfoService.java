package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.PageInfo;
import com.vietfintex.marketplace.web.dto.PageInfoDTO;

public interface PageInfoService extends IOperations<PageInfo,PageInfoDTO> {
}
