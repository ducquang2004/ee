package com.vietfintex.marketplace.web.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GlobalFeatueDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long globalFeatureId;
    private Long categoryId;
    private String valueKey;

    public Long getGlobalFeatureId() {
        return globalFeatureId;
    }

    public void setGlobalFeatureId(Long globalFeatureId) {
        this.globalFeatureId = globalFeatureId;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getValueKey() {
        return valueKey;
    }

    public void setValueKey(String valueKey) {
        this.valueKey = valueKey;
    }
}
