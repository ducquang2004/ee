package com.vietfintex.marketplace.web.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GetListDeliveryPlaceDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private int startResult;
    private int maxResult;
    private DeliveryPlaceDTO object;

    public int getStartResult() {
        return startResult;
    }

    public void setStartResult(int startResult) {
        this.startResult = startResult;
    }

    public int getMaxResult() {
        return maxResult;
    }

    public void setMaxResult(int maxResult) {
        this.maxResult = maxResult;
    }

    public DeliveryPlaceDTO getObject() {
        return object;
    }

    public void setObject(DeliveryPlaceDTO object) {
        this.object = object;
    }
}
