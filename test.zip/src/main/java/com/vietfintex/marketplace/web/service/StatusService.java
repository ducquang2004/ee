package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.Status;

import java.util.List;

public interface StatusService extends IOperations<Status, Status> {
    List<Status> findByType(String type);
}
