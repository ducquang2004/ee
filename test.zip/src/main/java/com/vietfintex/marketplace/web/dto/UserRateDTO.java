package com.vietfintex.marketplace.web.dto;


import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The persistent class for the user_rate database table.
 * 
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UserRateDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;
	private Long objectId;
	private String objectType;
	private Date updatedTime;
	private Long userId;
	private int value;

	public UserRateDTO() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getObjectId() {
		return this.objectId;
	}

	public void setObjectId(Long objectId) {
		this.objectId = objectId;
	}

	public String getObjectType() {
		return this.objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Long getUserId() {
		return this.userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public int getValue() {
		return this.value;
	}

	public void setValue(int value) {
		this.value = value;
	}

}
