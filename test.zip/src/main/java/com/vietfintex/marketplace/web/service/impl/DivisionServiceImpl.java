package com.vietfintex.marketplace.web.service.impl;

import com.vietfintex.marketplace.persistence.model.Division;
import com.vietfintex.marketplace.persistence.repo.DivisionRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.DivisionDTO;
import com.vietfintex.marketplace.web.service.DivisionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DivisionServiceImpl extends AbstractService<Division, DivisionDTO> implements DivisionService {
    private static final BaseMapper<Division, DivisionDTO> mapper = new BaseMapper<>(Division.class, DivisionDTO.class);

    @Autowired
    DivisionRepo divisionRepo;
    @Override
    public List<DivisionDTO> getByDivisionType(Long divisionType) {
        return getMapper().toDtoBean(divisionRepo.getByDivisionType(divisionType));
    }

    @Override
    protected PagingAndSortingRepository<Division, Long> getDao() {
        return divisionRepo;
    }

    @Override
    protected BaseMapper<Division, DivisionDTO> getMapper() {
        return mapper;
    }
}
