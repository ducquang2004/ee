package com.vietfintex.marketplace.web.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DivisionDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long divisionId;
    private Long divisionType;
    private Long divisionValue;
    private String divisionName;

    public Long getDivisionId() {
        return divisionId;
    }

    public void setDivisionId(Long divisionId) {
        this.divisionId = divisionId;
    }

    public Long getDivisionType() {
        return divisionType;
    }

    public void setDivisionType(Long divisionType) {
        this.divisionType = divisionType;
    }

    public Long getDivisionValue() {
        return divisionValue;
    }

    public void setDivisionValue(Long divisionValue) {
        this.divisionValue = divisionValue;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }
}
