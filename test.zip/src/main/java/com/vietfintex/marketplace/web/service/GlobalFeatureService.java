package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.GlobalFeature;
import com.vietfintex.marketplace.web.dto.GlobalFeatueDTO;

import java.util.List;

public interface GlobalFeatureService extends IOperations<GlobalFeature, GlobalFeatueDTO> {
    List<GlobalFeatueDTO> getGlobalFeatureByCategory(Long categoryId);
}
