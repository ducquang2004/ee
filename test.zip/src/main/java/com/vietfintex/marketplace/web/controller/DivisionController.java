package com.vietfintex.marketplace.web.controller;

import com.vietfintex.marketplace.web.dto.DivisionDTO;
import com.vietfintex.marketplace.web.dto.ResponseDTO;
import com.vietfintex.marketplace.web.service.DivisionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/division")
public class DivisionController {
    @Autowired
    DivisionService divisionService;

    @GetMapping(value = "/{divisionType}")
    @ResponseBody
    public ResponseDTO getDivisionByType(@PathVariable("divisionType") Long divisionType ){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            List<DivisionDTO> divisionDTOList = divisionService.getByDivisionType(divisionType);
            if (divisionDTOList != null){
                responseDTO.setSuccess(true);
                responseDTO.setObjectReturn(divisionDTOList);
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+e.toString());
        }
        return responseDTO;
    }
}
