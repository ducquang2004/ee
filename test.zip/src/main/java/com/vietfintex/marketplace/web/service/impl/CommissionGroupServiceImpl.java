package com.vietfintex.marketplace.web.service.impl;

import com.vietfintex.marketplace.persistence.model.CommissionGroup;
import com.vietfintex.marketplace.persistence.repo.CommissionGroupRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.CommissionGroupDTO;
import com.vietfintex.marketplace.web.service.CommissionGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommissionGroupServiceImpl extends AbstractService<CommissionGroup,CommissionGroupDTO> implements
        CommissionGroupService {
    private static final BaseMapper<CommissionGroup, CommissionGroupDTO> mapper =
            new BaseMapper<>(CommissionGroup.class, CommissionGroupDTO.class);
    @Autowired
    private CommissionGroupRepo repo;

    @Override
    protected PagingAndSortingRepository<CommissionGroup, Long> getDao() {
        return repo;
    }

    @Override
    protected BaseMapper<CommissionGroup, CommissionGroupDTO> getMapper() {
        return mapper;
    }

    @Override
    public CommissionGroupDTO getByGroupId(Long groupId) {
        return getMapper().toDtoBean(repo.getByGroupId(groupId));
    }

    @Override
    public CommissionGroupDTO insertOrUpdate(CommissionGroupDTO commissionGroupDTO) {
        return getMapper().toDtoBean(repo.save(getMapper().toPersistenceBean(commissionGroupDTO)));
    }

    @Override
    public CommissionGroupDTO getById(Long id) {
        return getMapper().toDtoBean(repo.getOne(id));
    }
}
