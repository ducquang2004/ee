package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.Order;
import com.vietfintex.marketplace.web.dto.OrderDTO;
import com.vietfintex.marketplace.web.dto.OrderDetailDTO;
import com.vietfintex.marketplace.web.dto.OrderDetailWrapDTO;
import com.vietfintex.marketplace.web.dto.OrderWrapDTO;

import java.util.List;

public interface OrderService extends IOperations<Order, OrderDTO> {
    List<OrderDTO> takeOrder(OrderWrapDTO orderWrapDTO);
    List<OrderDetailWrapDTO> getOrderListByUserId(Long UserId,Long deliveryStatus,int startResult, Long productOwnerId);
    OrderDetailDTO updateOrderStatus(OrderDetailDTO orderDetailDTO);
    OrderDetailDTO assignToTransport(OrderDetailDTO orderDetailDTO);
    OrderDetailDTO completeOrder(OrderDetailDTO orderDetailDTO);
}