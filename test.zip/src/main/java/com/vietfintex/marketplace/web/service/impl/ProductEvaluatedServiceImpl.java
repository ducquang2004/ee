package com.vietfintex.marketplace.web.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import com.vietfintex.marketplace.persistence.model.ProductEvaluated;
import com.vietfintex.marketplace.persistence.repo.ProductEvaluatedRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.ProductEvaluatedDTO;
import com.vietfintex.marketplace.web.service.ProductEvaluatedService;

@Service
public class ProductEvaluatedServiceImpl extends AbstractService<ProductEvaluated,ProductEvaluatedDTO> implements ProductEvaluatedService {
    @Autowired
    ProductEvaluatedRepo repo;
    private static final BaseMapper<ProductEvaluated, ProductEvaluatedDTO> mapper = new BaseMapper<>(ProductEvaluated.class,
            ProductEvaluatedDTO.class);

    @Override
    protected PagingAndSortingRepository<ProductEvaluated, Long> getDao() {
        return repo;
    }

    @Override
    protected BaseMapper<ProductEvaluated, ProductEvaluatedDTO> getMapper() {
        return mapper;
    }

	@Override
	public void updateLikeCount(String type, Long postId, int addValue) throws Exception {
		ProductEvaluatedDTO res = getEvaluated(type, postId);
		res.setLikeCount(res.getLikeCount() + addValue);
		save(res);
	}
	
	@Override
	public ProductEvaluatedDTO getEvaluated(String type,Long postId) {
		List<ProductEvaluated> lst = repo.findAllByObjectTypeAndObjectId(type, postId);
		if(lst !=null && !lst.isEmpty()) {
			return mapper.toDtoBean(lst.get(0));
		}
		return new ProductEvaluatedDTO(type,postId);
	}
}
