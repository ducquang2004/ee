package com.vietfintex.marketplace.web.controller;
import com.vietfintex.marketplace.web.dto.CommissionGroupDTO;
import com.vietfintex.marketplace.web.dto.ResponseDTO;
import com.vietfintex.marketplace.web.service.CommissionGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;


@RestController
@RequestMapping(value = "/api/commissionGroup")
public class CommissionGroupController {

    @Autowired
    CommissionGroupService commissionGroupService;

    @GetMapping(value = "/getByGroupId/{groupId}")
    @ResponseBody
    ResponseDTO getByGroupId(@PathVariable final Long groupId){
        ResponseDTO responseDTO = new ResponseDTO(true);
        try {
            CommissionGroupDTO returnObject = commissionGroupService.getByGroupId(groupId);
            if (returnObject != null){
                responseDTO.setSuccess(true);
                responseDTO.setObjectReturn(returnObject);
                return responseDTO;
            }
            responseDTO.setErrorMessage("Chua co du lieu");
            responseDTO.setSuccess(true);
            return responseDTO;
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return responseDTO;
    }

    @RequestMapping(value = "/insertOrUpdate")
    @ResponseBody
    ResponseDTO insertOrUpdate(@RequestBody CommissionGroupDTO commissionGroupDTO){
        ResponseDTO responseDTO = new ResponseDTO(true);
        try {
            Objects.requireNonNull(commissionGroupDTO,"Bạn chưa truyền dữ liệu");
            Objects.requireNonNull(commissionGroupDTO.getGroupId(),"Bạn chưa truyền groupId");
            Objects.requireNonNull(commissionGroupDTO.getBuyerPercent(),"Bạn chưa truyền chiết khấu cho người m");
            Objects.requireNonNull(commissionGroupDTO.getOwnerGroupPercent(),"Bạn chưa truyền chiết khẩu cho chủ hội nhóm");
            Objects.requireNonNull(commissionGroupDTO.getParentBuyerPercent(),"Bạn chưa truyền chiết khẩu cho người giới thiêụ");
            CommissionGroupDTO oldData = commissionGroupService.getByGroupId(commissionGroupDTO.getGroupId());
            //giu nguyen phan tram cho Smiletech  neu ban ghi chua ton tai thi add mac đinhj 20%
            if (oldData != null){
                commissionGroupDTO.setSmileTechPercent(oldData.getSmileTechPercent());
            }else{
                commissionGroupDTO.setSmileTechPercent(20D);
            }
            CommissionGroupDTO returnObject = commissionGroupService.save(commissionGroupDTO);
            if (returnObject != null){
                responseDTO.setObjectReturn(true);
                responseDTO.setObjectReturn(returnObject);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return responseDTO;
    }
}
