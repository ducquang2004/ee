package com.vietfintex.marketplace.web.controller;

import com.vietfintex.marketplace.web.dto.*;
import com.vietfintex.marketplace.web.service.ProductFeatureService;
import com.vietfintex.marketplace.web.service.ProductOptionMService;
import com.vietfintex.marketplace.web.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping(value = "/api/product")
public class ProductController {
    @Autowired
    ProductService productService;

    @Autowired
    ProductOptionMService productOptionMService;

    @Autowired
    ProductFeatureService productFeatureService;

    @GetMapping
    @ResponseBody
    public ResponseDTO search(ProductDTO searchDTO,
                              @RequestParam(value = "page", defaultValue = "0", required = false) Integer page,
                              @RequestParam(value = "size", defaultValue = "10", required = false) Integer size) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            List<ProductDTO> productDTOList = productService.search(searchDTO, PageRequest.of(page, size));
            response.setSuccess(true);
            for (int i = 0; i < productDTOList.size();i++){
                ProductDTO productDTO = productDTOList.get(i);
                productDTO.setDiscountPercent((int) (100 * (productDTO.getListPrice()
                        - productDTO.getPrice())/ productDTO.getListPrice()));
                productDTOList.set(i,productDTO);
            }
            response.setObjectReturn(productDTOList);
        } catch (Exception e) {
            response.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return response;
    }


    @RequestMapping(value = "/count", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDTO count(@RequestBody ProductDTO param) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            Long count = productService.count(param);
            response.setSuccess(true);
            response.setObjectReturn(count);
        } catch (Exception e) {
            response.setErrorMessage("Có lỗi xảy ra: " + e.getMessage());
        }
        return response;
    }

    @RequestMapping(value = "/", method = RequestMethod.POST)
    @ResponseBody
    @Transactional
    public ResponseDTO createProduct(@RequestBody ProductWrapDTO productWrapDTO) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            Objects.requireNonNull(productWrapDTO, "Not found productWrapDTO param");
            ProductDTO productDTO = productWrapDTO.getProductDTO();
            Objects.requireNonNull(productDTO, "Not found product param");
            List<ProductOptionMDTO> productOptionMDTOList = productWrapDTO.getProductOptionDTOList();
            productDTO = productService.save(productDTO);
            productDTO.setDiscountPercent((int) (100 * (productDTO.getListPrice()
                    - productDTO.getPrice())/ productDTO.getListPrice()));
            productWrapDTO.setProductDTO(productDTO);

            ProductOptionMDTO item;
            if (productOptionMDTOList != null){
                for (int i =0; i< productOptionMDTOList.size() ;i ++){
                    item = productOptionMDTOList.get(i);
                    item.setProductId(productDTO.getProductId());
                    productOptionMDTOList.set(i,item);
                }
                productOptionMDTOList =productOptionMService.insertOrUpdate(productOptionMDTOList);
                productWrapDTO.setProductOptionDTOList(productOptionMDTOList);
            }
            List<ProductFeatureDTO> productFeatureDTOList = productWrapDTO.getProductFeatureDTOList();
            if(productFeatureDTOList != null){
                for (int i =0; i<productFeatureDTOList.size();i++){
                    ProductFeatureDTO productFeatureDTO = productFeatureDTOList.get(i);
                    productFeatureDTO.setCategoryId(productDTO.getCategoryId());
                    productFeatureDTO.setProductId(productDTO.getProductId());
                    productFeatureDTOList.set(i, productFeatureDTO);
                }

                productFeatureDTOList = productFeatureService.saveAllProductFeature(productFeatureDTOList);
                productWrapDTO.setProductFeatureDTOList(productFeatureDTOList);
            }
            response.setSuccess(true);
            response.setObjectReturn(productWrapDTO);
            return response;
        } catch (Exception e) {
            response.setErrorMessage("Có lỗi xảy ra: " + e.getMessage());
        }
        return response;
    }

    @GetMapping(value = "/getTopProduct")
    @ResponseBody
    public ResponseDTO getTopProduct(){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            List<ProductDTO> returnObject = productService.getTopProduct();
            if (returnObject != null){
                responseDTO.setSuccess(true);
                responseDTO.setObjectReturn(returnObject);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Có lỗi xảy ra: " + e.getMessage());
        }
        return responseDTO;
    }

    @GetMapping(value = "/getProductById/{productId}")
    @ResponseBody
    public ResponseDTO getProductById(@PathVariable final Long productId){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            ProductDTO productDTO = productService.getProductById(productId);
            if (productDTO != null){
                responseDTO.setSuccess(true);
                responseDTO.setObjectReturn(productDTO);
                return responseDTO;
            }
            responseDTO.setErrorMessage("Không tìm thấy dữ liệu");
        }catch (Exception e){
            responseDTO.setErrorMessage("Có lỗi xảy ra: " + e.getMessage());
        }
        return responseDTO;
    }
}
