package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.DeliveryPlace;
import com.vietfintex.marketplace.web.dto.DeliveryPlaceDTO;

import java.util.List;

public interface DeliveryPlaceService extends IOperations<DeliveryPlace,DeliveryPlaceDTO> {
    List<DeliveryPlaceDTO> getDeliveryList(Integer startResult, Integer maxResult, DeliveryPlaceDTO deliveryPlaceDTO);
    DeliveryPlaceDTO insertOrUpdate(DeliveryPlaceDTO deliveryPlaceDTO);
    DeliveryPlaceDTO deleteItem(DeliveryPlaceDTO deliveryPlaceDTO);
}
