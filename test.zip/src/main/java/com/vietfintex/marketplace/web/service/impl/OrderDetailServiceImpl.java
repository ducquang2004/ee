package com.vietfintex.marketplace.web.service.impl;

import com.vietfintex.marketplace.persistence.model.OrderDetail;
import com.vietfintex.marketplace.persistence.repo.OrderDetailRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.OrderDetailDTO;
import com.vietfintex.marketplace.web.dto.ProductDTO;
import com.vietfintex.marketplace.web.service.GroupPostService;
import com.vietfintex.marketplace.web.service.OrderDetailService;
import com.vietfintex.marketplace.web.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderDetailServiceImpl extends AbstractService<OrderDetail,OrderDetailDTO> implements OrderDetailService {
    private static final BaseMapper<OrderDetail,OrderDetailDTO> mapper = new BaseMapper<>(OrderDetail.class, OrderDetailDTO.class);
    @Autowired
    OrderDetailRepo repo;

    @Autowired
    GroupPostService groupPostService;

    @Override
    public OrderDetailDTO updateStatus(OrderDetailDTO orderDetailDTO) {
        return getMapper().toDtoBean(repo.save(getMapper().toPersistenceBean(orderDetailDTO)));
    }

    @Override
    public OrderDetailDTO assignToTransport(OrderDetailDTO orderDetailDTO) {
        return null;
    }

    @Override
    public OrderDetailDTO completeOrder(OrderDetailDTO orderDetailDTO) {
        return repo.completeOrder(orderDetailDTO);
    }

    @Override
    protected PagingAndSortingRepository<OrderDetail, Long> getDao() {
        return repo;
    }

    @Override
    protected BaseMapper<OrderDetail, OrderDetailDTO> getMapper() {
        return mapper;
    }
}
