package com.vietfintex.marketplace.web.controller;


import com.vietfintex.marketplace.persistence.model.GroupClub;
import com.vietfintex.marketplace.persistence.model.GroupMember;
import com.vietfintex.marketplace.persistence.repo.GroupClubRepo;
import com.vietfintex.marketplace.persistence.repo.GroupMemberRepo;
import com.vietfintex.marketplace.web.dto.InvitationDTO;
import com.vietfintex.marketplace.web.dto.InvitationGetDTO;
import com.vietfintex.marketplace.web.dto.InvitationWrapDTO;
import com.vietfintex.marketplace.web.dto.ResponseDTO;
import com.vietfintex.marketplace.web.service.InvitationService;
import com.vietfintex.marketplace.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping(value = "/api/invitation")
public class InvitationController {

    @Autowired
    InvitationService invitationService;
    @Autowired
    UserService userService;
    @Autowired
    GroupMemberRepo groupMemberRepo;
    @Autowired
    GroupClubRepo groupClubRepo;

    @RequestMapping(value = "/insertOrUpdate", method = RequestMethod.POST)
    @ResponseBody
    @Transactional
    public ResponseDTO insertOrUpdate(@RequestBody final InvitationDTO invitationDTO){
        ResponseDTO responseDTO = new ResponseDTO(false);
        Objects.requireNonNull(invitationDTO,"not found required invitationDTP");
        responseDTO.setErrorMessage("Loi tham so");
        try {
                if (invitationDTO.getUserId() != null && userService.findOne(invitationDTO.getUserId()) == null){
                    responseDTO.setErrorMessage("Tai khoan ng duoc moi khong ton tai");
                    responseDTO.setErrorCode("201");
                    return responseDTO;
                }

                if (invitationDTO.getInviteUserId() == null || userService.findOne(invitationDTO.getInviteUserId()) == null){
                    responseDTO.setErrorMessage("Tai khoan ng gui loi moi khong ton tai");
                    responseDTO.setErrorCode("202");
                    return responseDTO;
                }

                if (invitationDTO.getGroupId() == null){
                    responseDTO.setErrorMessage("Club khong ton tai");
                    responseDTO.setErrorCode("203");
                    return responseDTO;
                }
                GroupMember groupMember = groupMemberRepo.findGroupMemberByGroupUser(null,invitationDTO.getGroupId(),invitationDTO.getInviteUserId());

                GroupClub groupClub = groupClubRepo.findById(groupMember.getGroupId()).orElse(null);
                if (groupClub == null){
                    responseDTO.setErrorMessage("Nhóm không tồn tại");
                    responseDTO.setErrorCode("205");
                    return responseDTO;
                }

                if (groupMember == null){
                    responseDTO.setErrorMessage("Nguoi gui loi moi chua phai la thanh vien hoi nhom");
                    responseDTO.setErrorCode("204");
                    return responseDTO;
                }
            InvitationDTO returnData = invitationService.insertOrUpdate(invitationDTO);
            if (returnData != null) {
                responseDTO.setErrorMessage(null);
                responseDTO.setObjectReturn(returnData);
                responseDTO.setSuccess(true);
                return responseDTO;
            }

        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+ e.toString());
        }
        return responseDTO;
    }

    @RequestMapping(value = "/inviteList", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDTO inviteList(@RequestBody InvitationWrapDTO invitationWrapDTO){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            Objects.requireNonNull(invitationWrapDTO,"Not found parameter");
            Objects.requireNonNull(invitationWrapDTO.getGroupId(),"Khong co group id");
            Objects.requireNonNull(invitationWrapDTO.getInviteUserId(),"Khong co userId cua ng gui loi moi");
            if (invitationWrapDTO.getGroupId() == null){
                responseDTO.setErrorMessage("Club khong ton tai");
                responseDTO.setErrorCode("203");
                return responseDTO;
            }
            GroupMember groupMember = groupMemberRepo.findGroupMemberByGroupUser(null,invitationWrapDTO.getGroupId(),invitationWrapDTO.getInviteUserId());

            if (groupMember == null){
                responseDTO.setErrorMessage("Nguoi gui loi moi chua phai la thanh vien hoi nhom");
                responseDTO.setErrorCode("204");
                return responseDTO;
            }

            GroupClub groupClub = groupClubRepo.findById(groupMember.getGroupId()).orElse(null);
            if (groupClub == null){
                responseDTO.setErrorMessage("Nhóm không tồn tại");
                responseDTO.setErrorCode("205");
                return responseDTO;
            }
            invitationService.inviteList(invitationWrapDTO.getUserList(),invitationWrapDTO.getPhoneList(),
                    invitationWrapDTO.getEmailList(), groupClub.getAccessKey(),
                    invitationWrapDTO.getInviteUserId(), invitationWrapDTO.getGroupId(), invitationWrapDTO.getInvitationContent());
            responseDTO.setSuccess(true);
            responseDTO.setErrorMessage(null);
            return  responseDTO;
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+e.getMessage());
        }
        return  responseDTO;
    }
    @GetMapping(value = "/getInvitation/{userId}/{status}/{startPage}")
    @ResponseBody
    public ResponseDTO getInvitation(@PathVariable final Long userId, @PathVariable final String status , @PathVariable final int startPage){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            List<InvitationGetDTO> returnObject = invitationService.getInvitationGetByUser(userId,status,startPage);
            responseDTO.setErrorMessage(null);
            responseDTO.setSuccess(true);
            responseDTO.setObjectReturn(returnObject);
            return responseDTO;
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+e.getMessage());
        }
        return responseDTO;
    }
}
