package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.Advertisement;
import com.vietfintex.marketplace.web.dto.AdvertisementDTO;

import java.util.List;

public interface AdvertisementService extends IOperations<Advertisement,AdvertisementDTO> {
    List<AdvertisementDTO> getAdvertisement();
}
