package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.OrderDetail;
import com.vietfintex.marketplace.web.dto.OrderDetailDTO;

public interface OrderDetailService extends IOperations<OrderDetail,OrderDetailDTO> {
    OrderDetailDTO updateStatus(OrderDetailDTO orderDetailDTO);
    OrderDetailDTO assignToTransport(OrderDetailDTO orderDetailDTO);
    OrderDetailDTO completeOrder(OrderDetailDTO orderDetailDTO);
}
