package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.UserLikePost;
import com.vietfintex.marketplace.web.dto.UserLikePostDTO;

public interface UserLikePostService extends IOperations<UserLikePost,UserLikePostDTO> {
	boolean likeDislikePost(String type,Long postId, Long userId)  throws Exception ;
	boolean isLikePost(String type,Long postId, Long userId);
}
