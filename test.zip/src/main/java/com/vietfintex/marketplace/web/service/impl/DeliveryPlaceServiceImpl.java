package com.vietfintex.marketplace.web.service.impl;

import com.vietfintex.marketplace.persistence.model.DeliveryPlace;
import com.vietfintex.marketplace.persistence.repo.DeliveryPlaceRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.DeliveryPlaceDTO;
import com.vietfintex.marketplace.web.service.DeliveryPlaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class DeliveryPlaceServiceImpl extends AbstractService<DeliveryPlace, DeliveryPlaceDTO> implements DeliveryPlaceService {
    private static final BaseMapper<DeliveryPlace, DeliveryPlaceDTO> mapper = new BaseMapper<>(DeliveryPlace.class, DeliveryPlaceDTO.class);
    @Autowired
    private DeliveryPlaceRepo repo;

    @Override
    public List<DeliveryPlaceDTO> getDeliveryList(Integer startResult, Integer maxResult, DeliveryPlaceDTO deliveryPlaceDTO) {
        return repo.getDeliveryList(startResult,maxResult,deliveryPlaceDTO);
    }

    @Override
    public DeliveryPlaceDTO insertOrUpdate(DeliveryPlaceDTO deliveryPlaceDTO) {
        Objects.requireNonNull(deliveryPlaceDTO, "not found required productDTO param");
        deliveryPlaceDTO = getMapper().toDtoBean(repo.save(getMapper().toPersistenceBean(deliveryPlaceDTO)));
        return deliveryPlaceDTO;
    }

    @Override
    public DeliveryPlaceDTO deleteItem(DeliveryPlaceDTO deliveryPlaceDTO) {
        Objects.requireNonNull(deliveryPlaceDTO, "not found required deliveryPlaceDTO param");
        Objects.requireNonNull(deliveryPlaceDTO.getDeliveryPlaceId(), "not found required deliveryPlaceId param");
        DeliveryPlace deliveryPlace = repo.getOne(deliveryPlaceDTO.getDeliveryPlaceId());
        if (deliveryPlace != null){
            repo.delete(getMapper().toPersistenceBean(deliveryPlaceDTO));
            return deliveryPlaceDTO;
        }
        return null;
    }


    @Override
    protected PagingAndSortingRepository<DeliveryPlace, Long> getDao() {
        return repo;
    }

    @Override
    protected BaseMapper<DeliveryPlace, DeliveryPlaceDTO> getMapper() {
        return mapper;
    }
}
