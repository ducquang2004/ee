package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.Invitation;
import com.vietfintex.marketplace.web.dto.InvitationDTO;
import com.vietfintex.marketplace.web.dto.InvitationGetDTO;

import java.util.List;

public interface InvitationService extends IOperations<Invitation, InvitationDTO> {
    boolean inviteList(List<Long> userIdList, List<String> phoneList, List<String> emailList
            , String groupAccessList, Long userId, Long groupId, String invitationContent);
    List<InvitationDTO> getInvitationByUser(Long userId, String status);
    List<InvitationGetDTO> getInvitationGetByUser(Long userId, String status, int startPage);
    InvitationDTO insertOrUpdate(InvitationDTO invitationDTO);
}
