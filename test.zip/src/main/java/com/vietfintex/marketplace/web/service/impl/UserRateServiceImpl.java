package com.vietfintex.marketplace.web.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import com.vietfintex.marketplace.persistence.model.UserRate;
import com.vietfintex.marketplace.persistence.repo.UserRateRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.UserRateDTO;
import com.vietfintex.marketplace.web.service.UserRateService;

@Service
public class UserRateServiceImpl extends AbstractService<UserRate,UserRateDTO> implements UserRateService {
    @Autowired
    UserRateRepo repo;
    private static final BaseMapper<UserRate, UserRateDTO> mapper = new BaseMapper<>(UserRate.class,
            UserRateDTO.class);

    @Override
    protected PagingAndSortingRepository<UserRate, Long> getDao() {
        return repo;
    }

    @Override
    protected BaseMapper<UserRate, UserRateDTO> getMapper() {
        return mapper;
    }
}
