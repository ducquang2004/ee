package com.vietfintex.marketplace.web.dto;

import java.io.Serializable;
import java.util.List;

public class GroupPostWrapDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private GroupPostDTO groupPostDTO;
    private ProductDTO productDTO;
    private StoreDTO storeDTO;
    private StoreCategoryDTO storeCategoryDTO;
    private List<String> imgPaths;

    public GroupPostDTO getGroupPostDTO() {
        return groupPostDTO;
    }

    public void setGroupPostDTO(GroupPostDTO groupPostDTO) {
        this.groupPostDTO = groupPostDTO;
    }

    public ProductDTO getProductDTO() {
        return productDTO;
    }

    public void setProductDTO(ProductDTO productDTO) {
        this.productDTO = productDTO;
    }

    public StoreDTO getStoreDTO() {
        return storeDTO;
    }

    public void setStoreDTO(StoreDTO storeDTO) {
        this.storeDTO = storeDTO;
    }

    public StoreCategoryDTO getStoreCategoryDTO() {
        return storeCategoryDTO;
    }

    public void setStoreCategoryDTO(StoreCategoryDTO storeCategoryDTO) {
        this.storeCategoryDTO = storeCategoryDTO;
    }

    public List<String> getImgPaths() {
        return imgPaths;
    }

    public void setImgPaths(List<String> imgPaths) {
        this.imgPaths = imgPaths;
    }
}
