package com.vietfintex.marketplace.web.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The persistent class for the product_evaluated database table.
 * 
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ProductEvaluatedDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String id;
	private int commentCount = 0;
	private int likeCount = 0;
	private Long objectId;
	private String objectType;
	private int rateCount = 0;
	private int rateTotal = 0;
	private float rateValue = 0;
	private Date updatedTime;

	public ProductEvaluatedDTO() {
	}
	
	public ProductEvaluatedDTO(String objectType,Long objectId) {
		this.objectType = objectType;
		this.objectId = objectId;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getCommentCount() {
		return this.commentCount;
	}

	public void setCommentCount(int commentCount) {
		this.commentCount = commentCount;
	}

	public int getLikeCount() {
		return this.likeCount;
	}

	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}

	public Long getObjectId() {
		return this.objectId;
	}

	public void setObjectId(Long objectId) {
		this.objectId = objectId;
	}

	public String getObjectType() {
		return this.objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public int getRateCount() {
		return this.rateCount;
	}

	public void setRateCount(int rateCount) {
		this.rateCount = rateCount;
	}

	public int getRateTotal() {
		return this.rateTotal;
	}

	public void setRateTotal(int rateTotal) {
		this.rateTotal = rateTotal;
	}

	public float getRateValue() {
		return this.rateValue;
	}

	public void setRateValue(float rateValue) {
		this.rateValue = rateValue;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

}