package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.UserRate;
import com.vietfintex.marketplace.web.dto.UserRateDTO;

public interface UserRateService extends IOperations<UserRate,UserRateDTO> {
}
