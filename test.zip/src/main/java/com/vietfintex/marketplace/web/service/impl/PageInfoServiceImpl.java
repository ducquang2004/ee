package com.vietfintex.marketplace.web.service.impl;

import com.vietfintex.marketplace.persistence.model.PageInfo;
import com.vietfintex.marketplace.persistence.repo.PageInfoRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.PageInfoDTO;
import com.vietfintex.marketplace.web.service.PageInfoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

@Service
public class PageInfoServiceImpl extends AbstractService<PageInfo,PageInfoDTO> implements PageInfoService {
    @Autowired
    PageInfoRepo repo;
    private static final BaseMapper<PageInfo, PageInfoDTO> mapper = new BaseMapper<>(PageInfo.class,
    		PageInfoDTO.class);


    @Override
    protected PagingAndSortingRepository<PageInfo, Long> getDao() {
        return repo;
    }

    @Override
    protected BaseMapper<PageInfo, PageInfoDTO> getMapper() {
        return mapper;
    }
}
