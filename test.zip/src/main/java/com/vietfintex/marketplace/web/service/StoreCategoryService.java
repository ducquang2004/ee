package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.StoreCategory;
import com.vietfintex.marketplace.web.dto.StoreCategoryDTO;

import java.util.List;

public interface StoreCategoryService extends IOperations<StoreCategory,StoreCategoryDTO> {
    StoreCategoryDTO modifyStoreCategory(StoreCategoryDTO storeCategoryWrap, String action);
    void storeCategoryChange(long storeId, List<Long>categoryIdList);
}
