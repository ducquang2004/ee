package com.vietfintex.marketplace.web.controller;

import com.vietfintex.marketplace.web.dto.GlobalFeatueDTO;
import com.vietfintex.marketplace.web.dto.ResponseDTO;
import com.vietfintex.marketplace.web.service.GlobalFeatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping(value = "/api/globalFeature")
public class GlobalFeatureController {

    @Autowired
    private GlobalFeatureService globalFeatureService;

    @GetMapping(value = "/getByCategory/{categoryId}")
    @ResponseBody
    private ResponseDTO getByCategory(@PathVariable("categoryId") Long categoryId){
        ResponseDTO responseDTO = new ResponseDTO(false);

        try {
            List<GlobalFeatueDTO> returnObject = globalFeatureService.getGlobalFeatureByCategory(categoryId);
            if (returnObject != null){
                responseDTO.setSuccess(true);
                responseDTO.setObjectReturn(returnObject);
                return  responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+e.getMessage());
        }
        return responseDTO;

    }
}
