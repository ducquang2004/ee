package com.vietfintex.marketplace.web.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import com.vietfintex.marketplace.persistence.model.UserLikePost;
import com.vietfintex.marketplace.persistence.repo.UserLikePostRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.UserLikePostDTO;
import com.vietfintex.marketplace.web.service.ProductEvaluatedService;
import com.vietfintex.marketplace.web.service.UserLikePostService;


@Service
public class UserLikePostServiceImpl  extends AbstractService<UserLikePost,UserLikePostDTO> implements UserLikePostService {
    private static final BaseMapper<UserLikePost, UserLikePostDTO> mapper = new BaseMapper<>(UserLikePost.class, UserLikePostDTO.class);
    @Autowired
    private UserLikePostRepo userLikePostRepo;
	
    @Autowired
    private ProductEvaluatedService productEvaluatedService;
	
//    @Autowired
//    private UserLikePostCustomRepo userLikePostCustomRepo;
//    
	@Override
	public boolean likeDislikePost(String type, Long postId, Long userId) throws Exception {
		List<UserLikePost> lst = userLikePostRepo.findAllByObjectTypeAndObjectIdAndUserId(type, postId, userId);
		if(lst == null || lst.isEmpty())
		{
			UserLikePostDTO userLikePost = new UserLikePostDTO();
			userLikePost.setLikeStatus(1);
			userLikePost.setObjectId(postId);
			userLikePost.setObjectType(type);
			userLikePost.setUserId(userId);
			save(userLikePost);
			productEvaluatedService.updateLikeCount(type,postId,1);
			return true;
		}
		boolean likeStatus = false;
		int addedVal = 1;
		UserLikePost userlikePost = lst.get(0);
		if(userlikePost.getLikeStatus() == 1) {
			userlikePost.setLikeStatus(0);
			addedVal = -1;
		}
		else {
			likeStatus =  true;
			userlikePost.setLikeStatus(1);
			addedVal = 1;
		}
		userLikePostRepo.save(userlikePost);
		productEvaluatedService.updateLikeCount(type,postId,addedVal);
		return likeStatus;
	}
	
	@Override
	public boolean isLikePost(String type, Long postId, Long userId) {
		List<UserLikePost> lst = userLikePostRepo.findAllByObjectTypeAndObjectIdAndUserId(type, postId, userId);
		if(lst == null)
		{
			return false;
		}
		boolean likeStatus = false;
		UserLikePost userlikePost = lst.get(0);
		if(userlikePost.getLikeStatus() == 1) {
			likeStatus =  true;
		}
		return likeStatus;
	}
	@Override
	protected PagingAndSortingRepository<UserLikePost, Long> getDao() {
		return userLikePostRepo;
	}
	@Override
	protected BaseMapper<UserLikePost, UserLikePostDTO> getMapper() {
		return mapper;
	}

}
