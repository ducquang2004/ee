package com.vietfintex.marketplace.web.controller;

import com.vietfintex.marketplace.web.dto.DeliveryPlaceDTO;
import com.vietfintex.marketplace.web.dto.GetListDeliveryPlaceDTO;
import com.vietfintex.marketplace.web.dto.ResponseDTO;
import com.vietfintex.marketplace.web.service.DeliveryPlaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping (value = "/api/deliveryPlace")
public class DeliveryPlaceController {
    @Autowired
    private DeliveryPlaceService deliveryPlaceService;

    @RequestMapping(value = "/getDeliveryPlace")
    @ResponseBody
    public ResponseDTO search(@RequestBody GetListDeliveryPlaceDTO getListObjectDTO){
        ResponseDTO response = new ResponseDTO(false);
        try {
            Objects.requireNonNull(getListObjectDTO, "not found required GetListDeliveryPlaceDTO param");
            Objects.requireNonNull(getListObjectDTO.getObject(), "not found required object param");
            List<DeliveryPlaceDTO> deliveryPlaceDTOList = deliveryPlaceService.getDeliveryList(getListObjectDTO.getStartResult(),
                    getListObjectDTO.getMaxResult(),getListObjectDTO.getObject());
            response.setSuccess(true);
            response.setObjectReturn(deliveryPlaceDTOList);
        } catch (Exception e) {
            response.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return response;
    }
    @RequestMapping (value = "/insertOrUpdate")
    @ResponseBody
    public ResponseDTO insertOrUpdate(@RequestBody DeliveryPlaceDTO deliveryPlaceDTO){
        ResponseDTO responseDTO = new ResponseDTO(false);
        if (deliveryPlaceDTO == null){
            responseDTO.setErrorMessage("Loi tham so truyen vao");
            return responseDTO;
        }
        try {
            DeliveryPlaceDTO returnObject = deliveryPlaceService.insertOrUpdate(deliveryPlaceDTO);
            if (returnObject != null){
                responseDTO.setObjectReturn(returnObject);
                responseDTO.setSuccess(true);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+e.getMessage());
        }
        responseDTO.setErrorMessage("Loi tham so truyen vao");
        return responseDTO;
    }

    @RequestMapping (value = "/delete")
    @ResponseBody
    public ResponseDTO delete(@RequestBody DeliveryPlaceDTO deliveryPlaceDTO){
        ResponseDTO responseDTO = new ResponseDTO(false);
        if (deliveryPlaceDTO == null || deliveryPlaceDTO.getDeliveryPlaceId() == null){
            responseDTO.setErrorMessage("Loi tham so truyen vao");
            return responseDTO;
        }
        try {
            DeliveryPlaceDTO returnObject = deliveryPlaceService.deleteItem(deliveryPlaceDTO);
            if (returnObject != null){
                responseDTO.setObjectReturn(returnObject);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+e.getMessage());
        }
        return responseDTO;
    }
}
