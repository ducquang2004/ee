package com.vietfintex.marketplace.web.service.impl;

import com.vietfintex.marketplace.persistence.model.GroupPost;
import com.vietfintex.marketplace.persistence.repo.GroupPostRepo;
import com.vietfintex.marketplace.persistence.repo.ImageRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.*;
import com.vietfintex.marketplace.web.service.GroupPostService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupPostServiceImpl extends  AbstractService<GroupPost,GroupPostDTO> implements GroupPostService {

    private static final Logger logger = Logger.getLogger(GroupPost.class);
    private static final BaseMapper<GroupPost, GroupPostDTO> mapper = new BaseMapper<>(GroupPost.class, GroupPostDTO.class);
    @Autowired
    private GroupPostRepo repo;

    @Autowired
    private ImageRepo imageRepo;
    @Override
    protected PagingAndSortingRepository<GroupPost, Long> getDao() {
        return repo;
    }
    @Override
    protected BaseMapper<GroupPost, GroupPostDTO> getMapper() {
        return mapper;
    }

    @Override
    public List<GroupPostWrapDTO> searchGroupPost(GroupPostDTO searchDTO, Pageable pageable) {
        List<GroupPostWrapDTO> returnData = repo.search(searchDTO,pageable);
        for (int i =0 ;i< returnData.size(); i++){
            GroupPostWrapDTO groupPostWrapDTO = returnData.get(i);
            ProductDTO productDTO = groupPostWrapDTO.getProductDTO();
            StoreDTO storeDTO = groupPostWrapDTO.getStoreDTO();
            if (productDTO != null && productDTO.getProductId() != null){
                List<ImageLinkDTO> imageLinkList = imageRepo.getImageLinkByObject(productDTO.getProductId(), "PRO");
                productDTO.setImageList(imageLinkList);
                groupPostWrapDTO.setProductDTO(productDTO);
                returnData.set(i,groupPostWrapDTO);
            }else if (storeDTO != null && storeDTO.getStoreId() != null){
                List<ImageLinkDTO> imageLinkList = imageRepo.getImageLinkByObject(storeDTO.getStoreId(), "STO");
                storeDTO.setImageLinkDTOList(imageLinkList);
                groupPostWrapDTO.setStoreDTO(storeDTO);
                returnData.set(i,groupPostWrapDTO);
            }
        }
        return returnData;
    }

    @Override
    public GroupPostDTO insertOrUpdate(GroupPostDTO groupPostDTO) {
        return getMapper().toDtoBean(repo.save(getMapper().toPersistenceBean(groupPostDTO)));
    }
}
