package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.Division;
import com.vietfintex.marketplace.web.dto.DivisionDTO;

import java.util.List;


public interface DivisionService extends IOperations<Division,DivisionDTO> {
    List<DivisionDTO> getByDivisionType(Long divisionType);
}
