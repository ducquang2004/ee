package com.vietfintex.marketplace.web.controller;

import com.vietfintex.marketplace.web.dto.AdvertisementDTO;
import com.vietfintex.marketplace.web.dto.PageInfoDTO;
import com.vietfintex.marketplace.web.dto.ResponseDTO;
import com.vietfintex.marketplace.web.service.AdvertisementService;
import com.vietfintex.marketplace.web.service.PageInfoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/page-info")
public class PageInfoController {
    @Autowired
    PageInfoService pageInfoService;

    @PostMapping("/create")
    @ResponseBody
    public ResponseDTO createPageInfoById(@RequestBody PageInfoDTO pageInfoDto){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            PageInfoDTO returnObject = pageInfoService.save(pageInfoDto);
            if (returnObject != null){
                responseDTO.setObjectReturn(returnObject);
                responseDTO.setSuccess(true);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+ e.getMessage());
        }
        return responseDTO;
    }
    
    @PutMapping("/update")
    @ResponseBody
    public ResponseDTO updatePageInfoById(@RequestBody PageInfoDTO pageInfoDto){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            PageInfoDTO returnObject = pageInfoService.update(pageInfoDto);
            if (returnObject != null){
                responseDTO.setObjectReturn(returnObject);
                responseDTO.setSuccess(true);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+ e.getMessage());
        }
        return responseDTO;
    }
    
    @GetMapping("/all")
    @ResponseBody
    public ResponseDTO getAllPageInfo(){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            List<PageInfoDTO> returnObject = pageInfoService.findAll();
            if (returnObject != null){
                responseDTO.setObjectReturn(returnObject);
                responseDTO.setSuccess(true);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+ e.getMessage());
        }
        return responseDTO;
    }

    @GetMapping("/find-by-id")
    @ResponseBody
    public ResponseDTO getPageInfoById(Long id){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            PageInfoDTO returnObject = pageInfoService.findOne(id);
            if (returnObject != null){
                responseDTO.setObjectReturn(returnObject);
                responseDTO.setSuccess(true);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+ e.getMessage());
        }
        return responseDTO;
    }
    
    
    @DeleteMapping("/delete")
    @ResponseBody
    public ResponseDTO deletePageInfo(Long id){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            pageInfoService.deleteById(id);
            responseDTO.setObjectReturn("success");
            responseDTO.setSuccess(true);
            return responseDTO;
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+ e.getMessage());
        }
        return responseDTO;
    }
    
}
