package com.vietfintex.marketplace.web.service.impl;

import com.vietfintex.marketplace.persistence.model.Advertisement;
import com.vietfintex.marketplace.persistence.repo.AdvertisementRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.web.dto.AdvertisementDTO;
import com.vietfintex.marketplace.web.service.AdvertisementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdvertisementServiceImpl extends AbstractService<Advertisement,AdvertisementDTO> implements AdvertisementService {
    @Autowired
    AdvertisementRepo repo;
    private static final BaseMapper<Advertisement, AdvertisementDTO> mapper = new BaseMapper<>(Advertisement.class,
            AdvertisementDTO.class);
    @Override
    public List<AdvertisementDTO> getAdvertisement() {
        return repo.getAdvertisement();
    }

    @Override
    protected PagingAndSortingRepository<Advertisement, Long> getDao() {
        return repo;
    }

    @Override
    protected BaseMapper<Advertisement, AdvertisementDTO> getMapper() {
        return mapper;
    }
}
