package com.vietfintex.marketplace.web.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class InvitationGetDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private InvitationDTO invitationDTO;
    private GroupClubDTO groupClubDTO;
    private UserDTO userDTO;

    public InvitationDTO getInvitationDTO() {
        return invitationDTO;
    }

    public void setInvitationDTO(InvitationDTO invitationDTO) {
        this.invitationDTO = invitationDTO;
    }

    public GroupClubDTO getGroupClubDTO() {
        return groupClubDTO;
    }

    public void setGroupClubDTO(GroupClubDTO groupClubDTO) {
        this.groupClubDTO = groupClubDTO;
    }

    public UserDTO getUserDTO() {
        return userDTO;
    }

    public void setUserDTO(UserDTO userDTO) {
        this.userDTO = userDTO;
    }
}
