package com.vietfintex.marketplace.web.controller;

import com.vietfintex.marketplace.persistence.model.GroupMember;
import com.vietfintex.marketplace.persistence.model.Product;
import com.vietfintex.marketplace.persistence.model.Store;
import com.vietfintex.marketplace.persistence.model.StoreCategory;
import com.vietfintex.marketplace.persistence.repo.*;
import com.vietfintex.marketplace.web.dto.*;
import com.vietfintex.marketplace.web.service.GroupClubService;
import com.vietfintex.marketplace.web.service.GroupPostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping(value = "/api/groupPost")
public class GroupPostController {
    @Autowired
    private GroupPostService groupPostService;
    @Autowired
    private GroupMemberRepo groupMemberRepo;
    @Autowired
    private ProductRepo productRepo;
    @Autowired
    private StoreRepo storeRepo;
    @Autowired
    private StoreCategoryRepo storeCategoryRepo;

    @GetMapping
    @ResponseBody
    public ResponseDTO search(GroupPostDTO searchDTO,
                              @RequestParam(value = "page", defaultValue = "0", required = false) Integer page,
                              @RequestParam(value = "size", defaultValue = "10", required = false) Integer size) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            List<GroupPostWrapDTO> returnObject = groupPostService.searchGroupPost(searchDTO,PageRequest.of(page, size));
            response.setObjectReturn(returnObject);
            response.setSuccess(true);

            return response;
        } catch (Exception e) {
            response.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return response;
    }
    @RequestMapping(value = "/insertOrUpdate", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDTO insertOrUpdate(@RequestBody final GroupPostDTO groupPostDTO){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            Objects.requireNonNull(groupPostDTO,"Lỗi tham số truyền vào");
            Objects.requireNonNull(groupPostDTO.getOwnerId(),"Trường ownerId chưa được truyền vào");
            Objects.requireNonNull(groupPostDTO.getGroupId(),"Trường groupId chưa được truyền");
            if (groupPostDTO.getProductId() == null && groupPostDTO.getCategoryStoreId() == null
                    && groupPostDTO.getStoreId() == null){
                responseDTO.setErrorMessage("Chưa truyền thông tin sản phẩm giảm giá");
                responseDTO.setErrorCode("201");
                return responseDTO;
            }
            if ((groupPostDTO.getProductId() != null && groupPostDTO.getStoreId() != null) ||
                    (groupPostDTO.getProductId() != null && groupPostDTO.getCategoryStoreId() != null) ||
                    (groupPostDTO.getCategoryStoreId() != null && groupPostDTO.getStoreId() != null)){
                responseDTO.setErrorMessage("Chỉ có thể truyền productId hoặc categoryStoreID hoặc storeId");
                responseDTO.setErrorCode("201");
                return  responseDTO;
            }
            if (groupPostDTO.getDiscountPercent() == null && groupPostDTO.getDiscountPrice() == null){
                responseDTO.setErrorMessage("Chưa truyền thông tin giảm giá");
                responseDTO.setErrorCode("201");
                return  responseDTO;
            }
            GroupMember groupMember = groupMemberRepo.findGroupMemberByGroupUser(null
                    ,groupPostDTO.getGroupId(),groupPostDTO.getOwnerId());
            if (groupMember == null){
                responseDTO.setErrorCode("201");
                responseDTO.setErrorMessage("Người dùng không có quyền");
                return responseDTO;
            }
            if (groupPostDTO.getProductId() != null){
                Product product = productRepo.findByProductIdAndProductOwnerId(groupPostDTO.getProductId(),groupPostDTO.getOwnerId());
                if (product == null ){
                    responseDTO.setErrorCode("201");
                    responseDTO.setErrorMessage("Người dùng không có quyền thêm sản phẩm này ");
                    return responseDTO;
                }
            }

            if (groupPostDTO.getStoreId() != null){
                Store store = storeRepo.getByOwnerIdAndStoreId(groupPostDTO.getOwnerId(),groupPostDTO.getStoreId());
                if (store == null){
                    responseDTO.setErrorCode("201");
                    responseDTO.setErrorMessage("Người dùng không có quyền thêm cửa hàng này ");
                    return responseDTO;
                }
            }

            if (groupPostDTO.getCategoryStoreId() != null){
                StoreCategory storeCategory = storeCategoryRepo.getStoreCategoryInfo(groupPostDTO.getCategoryStoreId(),groupPostDTO.getOwnerId());
                if (storeCategory == null){
                    responseDTO.setErrorCode("201");
                    responseDTO.setErrorMessage("Người dùng không có quyền thêm mặt hàng cửa hàng này ");
                    return responseDTO;
                }
            }

            //valide thong tin xong thuc hien luu lai
            GroupPostDTO returnObject = groupPostService.insertOrUpdate(groupPostDTO);
            if (returnObject != null){
                responseDTO.setObjectReturn(returnObject);
                responseDTO.setErrorCode("200");
                responseDTO.setSuccess(true);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+e.getMessage());
        }
        return responseDTO;
    }
}
