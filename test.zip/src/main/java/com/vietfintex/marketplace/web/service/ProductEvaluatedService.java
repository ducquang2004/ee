package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.ProductEvaluated;
import com.vietfintex.marketplace.web.dto.ProductEvaluatedDTO;

public interface ProductEvaluatedService extends IOperations<ProductEvaluated,ProductEvaluatedDTO> {

	void updateLikeCount(String type, Long postId, int addValue) throws Exception;
	
	ProductEvaluatedDTO getEvaluated(String type,Long postId);
}
