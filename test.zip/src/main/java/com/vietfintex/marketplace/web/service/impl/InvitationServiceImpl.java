package com.vietfintex.marketplace.web.service.impl;

import com.vietfintex.marketplace.persistence.model.GroupClub;
import com.vietfintex.marketplace.persistence.model.GroupMember;
import com.vietfintex.marketplace.persistence.model.Invitation;
import com.vietfintex.marketplace.persistence.model.User;
import com.vietfintex.marketplace.persistence.repo.GroupClubRepo;
import com.vietfintex.marketplace.persistence.repo.GroupMemberRepo;
import com.vietfintex.marketplace.persistence.repo.InvitationRepo;
import com.vietfintex.marketplace.persistence.repo.UserRepo;
import com.vietfintex.marketplace.util.BaseMapper;
import com.vietfintex.marketplace.util.GlobalUtil;
import com.vietfintex.marketplace.util.MailHelper;
import com.vietfintex.marketplace.web.dto.InvitationDTO;
import com.vietfintex.marketplace.web.dto.InvitationGetDTO;
import com.vietfintex.marketplace.web.service.InvitationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class InvitationServiceImpl extends AbstractService<Invitation, InvitationDTO> implements InvitationService {

    private static final BaseMapper<Invitation,InvitationDTO> mapper = new BaseMapper<>(Invitation.class,InvitationDTO.class);
    @Autowired
    InvitationRepo repo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    GroupMemberRepo groupMemberRepo;
    @Autowired
    InvitationRepo invitationRepo;
    @Autowired
    GroupClubRepo groupClubRepo;
    @Override
    protected PagingAndSortingRepository<Invitation, Long> getDao() {
        return repo;
    }

    @Override
    protected BaseMapper<Invitation, InvitationDTO> getMapper() {
        return mapper;
    }

    //Send email
    ApplicationContext context =
            new ClassPathXmlApplicationContext("spring-data.xml");

    MailHelper mm = (MailHelper) context.getBean("mailMail");

    @Override
    public boolean inviteList(List<Long> userIdList, List<String> phoneList, List<String> emailList
            , String groupAccessList, Long userId, Long groupId,String invitationContent) {
        //List phone, email đã được tìm thấy trong tài khỏan đã đăng ký
        List<String> existPhoneList = new ArrayList<>();
        List<String> existEmailList = new ArrayList<>();

        //List phone, email chưa đăng ký bao giờ
        List<String> newPhoneList = new ArrayList<>();
        List<String> newEmailList = new ArrayList<>();

        //List userId co the se gui loi
        List<Long> newUserIdList = new ArrayList<>();
        List<User> userList = userRepo.searchList(userIdList,phoneList,emailList);
        if (userList == null){
            if (emailList != null && emailList.size() > 0)
                inviteEmailList(groupId,emailList, groupAccessList,userId, invitationContent);
            if (phoneList != null && phoneList.size() > 0)
                invitePhoneList(groupId,phoneList, groupAccessList,userId, invitationContent);
            return true;
        }
        for(User user : userList){
            newUserIdList.add(user.getUserId());
            if (user.getEmail() != null)
                existEmailList.add(user.getEmail());
            if (user.getPhone() != null)
                existPhoneList.add(user.getPhone());
        }
        if (userList.size()>0){
            inviteUserList(newUserIdList, userList, groupAccessList,userId,groupId, invitationContent);
        }
        if (emailList != null && emailList.size() > 0) {
            for (String email : emailList) {
                if (!existEmailList.contains(email)) { //Loai những email đã được đăng ký. Email này nên được gửi thông báo theo user
                    newEmailList.add(email);
                }
            }
            if (newEmailList.size() > 0) {
                inviteEmailList(groupId,newEmailList, groupAccessList,userId, invitationContent);
            }
        }
        if (phoneList != null && phoneList.size() > 0) {
            for (String phone : phoneList) {
                if (!existPhoneList.contains(phone)) { //Loai những phone đã được đăng ký. Phone này nên được gửi thông báo theo user
                    newPhoneList.add(phone);
                }
            }
            if (newPhoneList.size() > 0) {
                invitePhoneList(groupId,newPhoneList, groupAccessList,userId, invitationContent);
            }
        }

        return false;
    }

    @Override
    public List<InvitationDTO> getInvitationByUser(Long userId, String status) {
        return null;
    }

    @Override
    public List<InvitationGetDTO> getInvitationGetByUser(Long userId, String status, int startPage) {
        return invitationRepo.getInvitationGetByUser(userId,status,startPage);
    }

    @Override
    @Transactional
    public InvitationDTO insertOrUpdate(InvitationDTO invitationDTO) {
        //Kiem tra group ton tai hay khong
        GroupClub groupClub = groupClubRepo.findById(invitationDTO.getGroupId()).orElse(null);
        if (groupClub != null) {
            String rawAccessKey = groupClub.getAccessKey()+"@"+invitationDTO.getInviteUserId()+"@";
            String userIdAccessKey = rawAccessKey;
            String phoneAccessKey = rawAccessKey;
            String mailAccessKey = rawAccessKey;
            //Chi can 1 trong 3 dk thoa man thi accessKey la hop le
            if (invitationDTO.getUserId() != null){
                userIdAccessKey += invitationDTO.getUserId();
                userIdAccessKey = invitationDTO.getGroupId()+"-"+GlobalUtil.sha256(userIdAccessKey)+"-"+invitationDTO.getInviteUserId();
            }
            if (invitationDTO.getUserPhone() != null){
                phoneAccessKey += invitationDTO.getUserPhone();
                phoneAccessKey = invitationDTO.getGroupId()+"-"+GlobalUtil.sha256(phoneAccessKey)+"-"+invitationDTO.getInviteUserId();
            }
            if (invitationDTO.getUserMail() != null){
                mailAccessKey += invitationDTO.getUserMail();
                mailAccessKey = invitationDTO.getGroupId()+"-"+GlobalUtil.sha256(mailAccessKey)+"-"+invitationDTO.getInviteUserId();
            }
            if (!(userIdAccessKey.equalsIgnoreCase(invitationDTO.getAccessKey()) ||
                    phoneAccessKey.equalsIgnoreCase(invitationDTO.getAccessKey())||
                    mailAccessKey.equalsIgnoreCase(invitationDTO.getAccessKey()))){
                return null;
            }

            if (invitationDTO != null) {
                //kiem tra & cap nhat vao bang group_member.
                if ("A".equalsIgnoreCase(invitationDTO.getStatus())) { //User Accept moi thuc hien them user vao bang group_member va tang count len
                    GroupMember groupMember = groupMemberRepo.findGroupMemberByGroupUser(null, invitationDTO.getGroupId(), invitationDTO.getUserId());

                    if (groupMember == null) {
                        groupMember = new GroupMember();
                        groupMember.setGroupId(invitationDTO.getGroupId());
                        groupMember.setUserId(invitationDTO.getUserId());
                        groupMember.setStatus("A");
                        groupMember.setLevel(1);
                        groupMember.setParentUserId(invitationDTO.getInviteUserId());
                        groupMemberRepo.save(groupMember);
                    }
                    //Them so luong group
                    groupClub.setMemberCount(groupMemberRepo.getMemberCountByGroupId(groupClub.getGroupId()));
                    groupClubRepo.save(groupClub);

                    //Xoa bang invitation truong hop user da dong y
                    //invitationRepo.deleteById(invitationDTO.getInvitationId());
                    invitationRepo.delete(getMapper().toPersistenceBean(invitationDTO));
                }else{
                    invitationRepo.save(getMapper().toPersistenceBean(invitationDTO));
                }
                return invitationDTO;
            }
        }
        return null;
    }

    private void inviteEmailList(Long groupId,List<String> emailList, String groupAccessList, Long userId,String invitationContent){
        for (String mail :emailList) {
            String secretKey = groupId + "-"+ GlobalUtil.sha256(groupAccessList + "@" + userId + "@" + mail)+"-"+userId;
            sendEmail(mail,invitationContent+"\nVui lòng sử dụng mã sau để xác thực: \n" + secretKey);
        }
    }
    private void invitePhoneList(Long groupId,List<String> phoneList, String groupAccessList, Long userId,String invitationContent){
        for (String phone :phoneList) {
            String secretKey = groupId + "-"+ GlobalUtil.sha256(groupAccessList + "@" + userId + "@" + phone)+"-"+userId;
            sendSms(phone, invitationContent+"\nVui lòng sử dụng mã sau để xác thực: \n" +secretKey);
        }
    }
    private void inviteUserList(List<Long> userIdList,List<User> userList, String groupAccessList, Long userId,Long groupId,String invitationContent){
        List<Long> memberUserIdList = groupMemberRepo.getUserMemberList(userIdList,groupId);
        List<Invitation> invitationList = new ArrayList<>();
        for(User user : userList){
            if (!memberUserIdList.contains(user.getUserId())){ //User chua phai la thanh vien cua nhom
                Invitation invitation = invitationRepo.getByUserIdAndGroupId(user.getUserId(),groupId);
                if (invitation == null)
                    invitation = new Invitation();
                invitation.setUserId(user.getUserId());
                invitation.setGroupId(groupId);
                invitation.setInvitationContent(invitationContent);
                invitation.setInviteUserId(userId);
                invitation.setStatus("N");
                invitation.setUserMail(user.getEmail());
                invitation.setUserPhone(user.getPhone());
                invitation.setAccessKey(groupId + "-"+ GlobalUtil.sha256(groupAccessList + "@" + userId + "@" + user.getUserId())+"-"+userId);
                invitationList.add(invitation);
                if (user.getEmail() != null){
                    String secretKey = groupId + "-"+ GlobalUtil.sha256(groupAccessList + "@" + userId + "@" + user.getEmail())+"-"+userId;
                    sendEmail(user.getEmail(),invitationContent+"\nVui lòng sử dụng mã sau để xác thực: \n" +secretKey);
                }
                if (user.getPhone() != null){
                    String secretKey = groupId + "-"+ GlobalUtil.sha256(groupAccessList + "@" + userId + "@" + user.getPhone())+"-"+userId;
                    sendSms(user.getPhone(),invitationContent+"\nVui lòng sử dụng mã sau để xác thực: \n" +secretKey);
                }
            }
        }
        if (invitationList.size() > 0){
            invitationRepo.saveAll(invitationList);
        }
    }
    private void sendSms(String phone, String content){
        //Send sms
    }
    private void sendEmail(String email, String content){
        try {
            mm.sendMail("smiletech.com@gmail.com",
                    email,
                    "Lời mời thân ái từ SmileTech",
                    "Bạn vừa nhận được lời nhắn từ bạn bè tham gia vào group tại SmileTech với nhiều ưu đãi khi mua hàng hoá" +
                            "\n" + content);
        }catch (Exception e){

        }
    }
    private void pushFireBase(){

    }
}
