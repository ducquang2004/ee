package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.ProductFeature;
import com.vietfintex.marketplace.web.dto.ProductFeatureDTO;

import java.util.List;

public interface ProductFeatureService extends IOperations<ProductFeature, ProductFeatureDTO> {
    List<ProductFeatureDTO> saveAllProductFeature(List<ProductFeatureDTO> productFeatureDTOList);
    List<ProductFeatureDTO> getProductFeature(Long productId);
}
