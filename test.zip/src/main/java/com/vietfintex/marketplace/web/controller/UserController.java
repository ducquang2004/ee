package com.vietfintex.marketplace.web.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vietfintex.marketplace.persistence.model.User;
import com.vietfintex.marketplace.util.GlobalUtil;
import com.vietfintex.marketplace.web.dto.ResponseDTO;
import com.vietfintex.marketplace.web.dto.UserDTO;
import com.vietfintex.marketplace.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.Objects.isNull;
import static java.util.Objects.requireNonNull;

@RestController
@RequestMapping(value = "/api/users")
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(value = "/search", method = RequestMethod.GET)
    @ResponseBody
    public ResponseDTO search(@RequestParam Map<String, Object> param, @PageableDefault(sort = {"username", "email"}) Pageable pageable) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            param = Optional.ofNullable(param).orElseGet(HashMap::new);
            ObjectMapper mapper = new ObjectMapper();
            UserDTO searchDTO = Optional.ofNullable(param.get("searchDTO"))
                    .map(x -> mapper.convertValue(x, UserDTO.class))
                    .orElseGet(UserDTO::new);
//            int startPage = (int) param.get("startPage");
//            int pageSize = (int) param.get("pageSize");
            List<UserDTO> users = userService.search(searchDTO, pageable.getPageNumber(), pageable.getPageSize());
            response.setSuccess(true);
            response.setObjectReturn(users);
        } catch (Exception e) {
            response.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return response;
    }

    @RequestMapping(value = "/count", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDTO count(@RequestBody Map<String, Object> param) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            param = Optional.ofNullable(param).orElseGet(HashMap::new);
            ObjectMapper mapper = new ObjectMapper();
            UserDTO searchDTO = Optional.ofNullable(param.get("searchDTO"))
                    .map(x -> mapper.convertValue(x, UserDTO.class))
                    .orElseGet(UserDTO::new);
            response.setSuccess(true);
            response.setObjectReturn(userService.count(searchDTO));
        } catch (Exception e) {
            response.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return response;
    }


    @RequestMapping(value = "/{userId}", method = RequestMethod.GET)
    @ResponseBody
    public ResponseDTO findByUserId(@PathVariable final Long userId) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            if (isNull(userId)) {
                response.setErrorMessage("userId must be not null");
                return response;
            }
            UserDTO users = userService.findOne(userId);
            response.setSuccess(true);
            response.setObjectReturn(users);
        } catch (Exception e) {
            response.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return response;
    }

    @PostMapping(value = "/login-admin")
    @ResponseBody
    public ResponseDTO login(@RequestBody Map<String, String> param) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            requireNonNull(param, "param not found");
            String username = GlobalUtil.requireNonEmpty(param.get("username"), "username must be not null");
            String password = GlobalUtil.requireNonEmpty(param.get("password"), "password must be not null");
            UserDTO users = userService.loginAdmin(username, password);
            requireNonNull(users, "not found user");
            response.setSuccess(true);
            response.setObjectReturn(users);
        } catch (Exception e) {
            response.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return response;
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDTO register(@RequestBody final UserDTO user) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            userService.validate(user);
            UserDTO checkUser = userService.checkUser(user.getUserName() != null?
                user.getUserName():"",user.getEmail() != null?
                    user.getEmail():"",user.getPhone() != null?
                    user.getPhone():"");
            if(checkUser == null) {
                UserDTO users = userService.register(user);
                response.setSuccess(true);
                response.setObjectReturn(users);
            }else {
                String msg ="";
                if(user.getUserName() != null && user.getUserName().equals(checkUser.getUserName())){
                    msg += "Tên đăng nhập đã được sử dụng";
                }
                if(user.getEmail() != null && user.getEmail().equals(checkUser.getEmail())){
                    msg += "\nEmail đã được sử dụng";
                }
                if(user.getPhone() != null && user.getPhone().equals(checkUser.getPhone())){
                    msg += "\nSố điện thoại đã được sử dụng";
                }
                response.setSuccess(false);
                response.setErrorCode("201");
                response.setErrorMessage(msg);
            }
        } catch (Exception e) {
            response.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return response;
    }
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ResponseBody
    public  ResponseDTO login(@RequestBody final  UserDTO user){
        ResponseDTO response = new ResponseDTO(false);
        try{
            if(GlobalUtil.isNullOrEmpty(user.getUserName())){
                response.setErrorMessage("Vui lòng nhập tên đăng nhập, số điện thoại hoặc email để đăng nhập");
                return response;
            }else if(GlobalUtil.isNullOrEmpty(user.getPassword())){
                response.setErrorMessage("Vui lòng nhập mật khẩu để đăng nhập");
                return response;
            }else {
                UserDTO userDTO = userService.login(
                        user.getUserName(),
                        user.getPassword());
                if(userDTO == null){
                    response.setSuccess(false);
                    response.setErrorMessage("Sai tên đăng nhập hoặc mật khẩu");
                    return response;
                }
                response.setSuccess(true);
                response.setObjectReturn(userDTO);
                return response;
            }
        }catch (Exception e){
            response.setErrorMessage("Co loi xay ra: "+ e.getMessage());
        }
        return response;
    }
    @PostMapping(value = "/")
    @ResponseBody
    public  ResponseDTO update(@RequestBody UserDTO user){
        ResponseDTO response = new ResponseDTO(false);
        try{
            user = requireNonNull(user, "Not found user param");
            UserDTO userDTO = userService.update(user);
            requireNonNull(userDTO, "Error save info user");
            response.setSuccess(true);
            response.setObjectReturn(userDTO);
        }catch (Exception e){
            response.setErrorMessage("Co loi xay ra: "+ e.getMessage());
        }
        return response;
    }

    @GetMapping(value = "/validateUser/{validateKey}")
    @ResponseBody
    public ResponseDTO validateUser(@PathVariable final String validateKey){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            UserDTO  userDTO = userService.validateUser(validateKey);
            if (userDTO == null){
                responseDTO.setErrorMessage("Không tìm thấy thông tin tài khoản");
            }else{
                responseDTO.setSuccess(true);
                responseDTO.setObjectReturn(userDTO);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra: "+ e.getMessage());
        }
        return responseDTO;
    }
}
