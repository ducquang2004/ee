package com.vietfintex.marketplace.web.controller;

import com.vietfintex.marketplace.persistence.repo.ImageRepo;
import com.vietfintex.marketplace.util.Constant;
import com.vietfintex.marketplace.web.dto.*;
import com.vietfintex.marketplace.web.service.OrderDetailService;
import com.vietfintex.marketplace.web.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@RestController
@RequestMapping(value = "/api/orders")
public class OrderController {
    @Autowired
    OrderService orderService;

    @Autowired
    ImageRepo repo;

    @Autowired
    OrderDetailService orderDetailService;

    @PostMapping(value = "/search")
    @ResponseBody
    public ResponseDTO search(@RequestBody final Map<String, Object> param) {
        ResponseDTO response = new ResponseDTO(false);
        try {

        } catch (Exception e) {
            response.setErrorMessage("Có lỗi xảy ra: " + e.getMessage());
        }
        return response;
    }


    @RequestMapping(value = "/count", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDTO count(@RequestBody Map<String, Object> param) {
        ResponseDTO response = new ResponseDTO(false);
        try {

        } catch (Exception e) {
            response.setErrorMessage("Có lỗi xảy ra: " + e.getMessage());
        }
        return response;
    }
    @RequestMapping(value = "/updateStatus", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDTO updateStatus(@RequestBody UpdateOrderDTO updateOrderDTO) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            Objects.requireNonNull(updateOrderDTO, "not found required orderDTO param");
            Objects.requireNonNull(updateOrderDTO.getUserId(), "not found required order user param");
            Objects.requireNonNull(updateOrderDTO.getOrderDetail(), "not found required orderDetail param");
            Objects.requireNonNull(updateOrderDTO.getOrderDetail().getItemId(), "not found required orderDetail id param");
            OrderDetailDTO returnObject = orderDetailService.updateStatus(updateOrderDTO.getOrderDetail());
            if (returnObject != null) {
                response.setSuccess(true);
                response.setObjectReturn(returnObject);
                return response;
            }
        } catch (Exception e) {
            response.setErrorMessage("Có lỗi xảy ra: " + e.getMessage());
        }
        return response;
    }
    @RequestMapping(value = "/completeOrder", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDTO completeOrder(@RequestBody UpdateOrderDTO updateOrderDTO) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            Objects.requireNonNull(updateOrderDTO, "not found required orderDTO param");
            Objects.requireNonNull(updateOrderDTO.getUserId(), "not found required order user param");
            Objects.requireNonNull(updateOrderDTO.getOrderDetail(), "not found required orderDetail param");
            Objects.requireNonNull(updateOrderDTO.getOrderDetail().getItemId(), "not found required orderDetail id param");
            OrderDetailDTO returnObject = orderDetailService.completeOrder(updateOrderDTO.getOrderDetail());
            if (returnObject != null) {
                response.setSuccess(true);
                response.setObjectReturn(returnObject);
                return response;
            }
        } catch (Exception e) {
            response.setErrorMessage("Có lỗi xảy ra: " + e.getMessage());
        }
        return response;
    }

    @RequestMapping(value = "/assignToTransport", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDTO assignToTransport(@RequestBody UpdateOrderDTO updateOrderDTO) {
        ResponseDTO response = new ResponseDTO(false);
        try {
            Objects.requireNonNull(updateOrderDTO, "not found required orderDTO param");
            Objects.requireNonNull(updateOrderDTO.getUserId(), "not found required order user param");
            Objects.requireNonNull(updateOrderDTO.getOrderDetail(), "not found required orderDetail param");
            Objects.requireNonNull(updateOrderDTO.getOrderDetail().getItemId(), "not found required orderDetail id param");
            OrderDetailDTO returnObject = orderDetailService.assignToTransport(updateOrderDTO.getOrderDetail());
            if (returnObject != null) {
                response.setSuccess(true);
                response.setObjectReturn(returnObject);
                return response;
            }
        } catch (Exception e) {
            response.setErrorMessage("Có lỗi xảy ra: " + e.getMessage());
        }
        return response;
    }
    @RequestMapping(value = "/takeOrder",method = RequestMethod.POST)
    @ResponseBody
    public  ResponseDTO takeOrder(@RequestBody OrderWrapDTO orderWrapDTO){
        ResponseDTO response = new ResponseDTO(false);
        response.setErrorMessage("Có lỗi xảy ra");
        try {
            Objects.requireNonNull(orderWrapDTO, "not found required orderWrapDTO param");
            Objects.requireNonNull(orderWrapDTO.getUserId(), "not found required userId param");
            Objects.requireNonNull(orderWrapDTO.getDeliveryPlaceId(), "not found required DeliveryPlaceId param");
            Objects.requireNonNull(orderWrapDTO.getProductDTOList(), "not found required ProductDTOList param");
            Objects.requireNonNull(orderWrapDTO.getQuantity(), "not found required quantity param");
            Objects.requireNonNull(orderWrapDTO.getStatusId(), "not found required StatusId param");
            List<OrderDTO> returnData = orderService.takeOrder(orderWrapDTO);
            if (returnData != null){
                response.setObjectReturn(returnData);
                response.setSuccess(true);
                response.setErrorMessage(null);
                return response;
            }

        }catch (Exception e){
            response.setErrorMessage("Có lỗi xảy ra: " + e.getMessage());
        }
        return response;
    }
    @GetMapping(value = "/getOrderListByUserId/{type}/{userId}/{deliveryStatus}/{startResult}")
    @ResponseBody
    public  ResponseDTO getOrderListByUserId(@PathVariable("type") String type,@PathVariable("userId") Long userId,@PathVariable("deliveryStatus") Long deliveryStatus,@PathVariable("startResult") int startResult){
        ResponseDTO response = new ResponseDTO(false);
        try {
            List<OrderDetailWrapDTO> orderDetailWrapDTOList;
            if ("buyer".equalsIgnoreCase(type)){
                orderDetailWrapDTOList = orderService.getOrderListByUserId(userId,deliveryStatus,startResult,null);
            }else {
                orderDetailWrapDTOList = orderService.getOrderListByUserId(null,deliveryStatus,startResult,userId);
            }

            if ( orderDetailWrapDTOList != null){
                for (int i =0 ; i< orderDetailWrapDTOList.size();i++){
                    OrderDetailWrapDTO orderDetailWrapDTO = orderDetailWrapDTOList.get(i);
                    List<ImageLinkDTO > imageLinkDTOList = repo.getImageLinkByObject(orderDetailWrapDTO.getProductId(),Constant.productImg);
                    orderDetailWrapDTO.setImageLinkDTOList(imageLinkDTOList);
                    orderDetailWrapDTOList.set(i,orderDetailWrapDTO);
                }
                response.setSuccess(true);
                response.setObjectReturn(orderDetailWrapDTOList);
                return response;
            }
        } catch (Exception e) {
            response.setErrorMessage("Co loi xay ra: " + e.getMessage());
        }
        return response;
    }
}
