package com.vietfintex.marketplace.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vietfintex.marketplace.web.dto.ResponseDTO;
import com.vietfintex.marketplace.web.dto.UserLikePostDTO;
import com.vietfintex.marketplace.web.service.UserLikePostService;

@RestController
@RequestMapping("/api/userlikepost")
public class UserLikePostController {
    @Autowired
    UserLikePostService userLikePostService;

    @PutMapping("/likepost")
    @ResponseBody
    public ResponseDTO likePost(Long userId,String type,Long postId){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            boolean returnObject = userLikePostService.likeDislikePost(type, postId, userId);
            responseDTO.setObjectReturn(returnObject);
            responseDTO.setSuccess(true);
            return responseDTO;
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+ e.getMessage());
        }
        return responseDTO;
    }
    
    @GetMapping("/all")
    @ResponseBody
    public ResponseDTO getUserLikePost(){
        ResponseDTO responseDTO = new ResponseDTO(false);
        try {
            List<UserLikePostDTO> returnObject = userLikePostService.findAll();
            if (returnObject != null){
                responseDTO.setObjectReturn(returnObject);
                responseDTO.setSuccess(true);
                return responseDTO;
            }
        }catch (Exception e){
            responseDTO.setErrorMessage("Co loi xay ra "+ e.getMessage());
        }
        return responseDTO;
    }
}
