/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vietfintex.marketplace.web.dto;

import java.io.Serializable;
import java.util.List;

public class ProductFeatureDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Long featureId;
    private Long globalFeatureId;
    private Long categoryId;
    private String fullDescription;
    private Long productId;
    private String featureName;

    private List<ProductFeatureVariantDTO> featureVariants;

    public List<ProductFeatureVariantDTO> getFeatureVariants() {
        return featureVariants;
    }

    public void setFeatureVariants(List<ProductFeatureVariantDTO> featureVariants) {
        this.featureVariants = featureVariants;
    }

    public Long getFeatureId() {
        return featureId;
    }

    public void setFeatureId(Long featureId) {
        this.featureId = featureId;
    }

    public Long getGlobalFeatureId() {
        return globalFeatureId;
    }

    public void setGlobalFeatureId(Long globalFeatureId) {
        this.globalFeatureId = globalFeatureId;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getFullDescription() {
        return fullDescription;
    }

    public void setFullDescription(String fullDescription) {
        this.fullDescription = fullDescription;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (featureId != null ? featureId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProductFeatureDTO)) {
            return false;
        }
        ProductFeatureDTO other = (ProductFeatureDTO) object;
        if ((this.featureId == null && other.featureId != null) || (this.featureId != null && !this.featureId.equals(other.featureId))) {
            return false;
        }
        return true;
    }

}
