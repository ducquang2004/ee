package com.vietfintex.marketplace.web.service;

import com.vietfintex.marketplace.persistence.model.GroupPost;
import com.vietfintex.marketplace.web.dto.GroupPostDTO;
import com.vietfintex.marketplace.web.dto.GroupPostWrapDTO;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface GroupPostService extends IOperations<GroupPost,GroupPostDTO> {
    GroupPostDTO insertOrUpdate(GroupPostDTO groupPostDTO);
    List<GroupPostWrapDTO> searchGroupPost(GroupPostDTO searchDTO, Pageable pageable);
}
