package com.vietfintex.marketplace.persistence.repo.impl;

import com.vietfintex.marketplace.persistence.repo.AdvertisementCustomRepo;
import com.vietfintex.marketplace.util.GlobalUtil;
import com.vietfintex.marketplace.util.NumberUtils;
import com.vietfintex.marketplace.web.dto.AdvertisementDTO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.isNull;

public class AdvertisementCustomRepoImpl implements AdvertisementCustomRepo {
    @PersistenceContext
    private EntityManager em;
    @Override
    public List<AdvertisementDTO> getAdvertisement() {
        String sql = "SELECT ad.advert_id as advertId, ad.company_id as companyId, ad.url as url "
                +" ,ad.start_date as startDate, ad.expired_date as expiredDate, ad.start_time "
                +"as startTime, ad.end_time  as endTime, ad.img_name as imgName, ad.is_active  "
                +" as isActive, ad.cost as cost FROM advertisement as ad  ";
        Query query = em.createNativeQuery(sql);
        query.setMaxResults(5);
        List<Object[]> lst = query.getResultList();
        List<AdvertisementDTO> returnList = new ArrayList<>();
        if(isNull(lst)){
            return null;
        }
        int i;
        for (Object[] obj: lst) {
            i = 0;
            AdvertisementDTO advertisementDTO = new AdvertisementDTO();
            advertisementDTO.setAdvertId(NumberUtils.convertToLong(obj[i++]));
            advertisementDTO.setCompanyId(NumberUtils.convertToLong(obj[i++]));
            advertisementDTO.setUrl(GlobalUtil.convertToString(obj[i++]));
            advertisementDTO.setStartDate(GlobalUtil.convertObjectToDate(obj[i++]));
            advertisementDTO.setExpiredDate(GlobalUtil.convertObjectToDate(obj[i++]));
            advertisementDTO.setStartTime(NumberUtils.convertToInt(obj[i++]));
            advertisementDTO.setEndTime(NumberUtils.convertToInt(obj[i++]));
            advertisementDTO.setImgName(GlobalUtil.convertToString(obj[i++]));
            advertisementDTO.setIsActive(NumberUtils.convertToInt(obj[i++]));
            advertisementDTO.setCost(NumberUtils.convertToDouble(obj[i++]));
            advertisementDTO.setImgPath("/resources/images/advertisement/"+advertisementDTO.getImgName());
            returnList.add(advertisementDTO);
        }
        return returnList;
    }
}
