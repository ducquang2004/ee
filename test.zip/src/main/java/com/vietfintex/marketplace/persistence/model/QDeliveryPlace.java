package com.vietfintex.marketplace.persistence.model;

import com.querydsl.core.types.Path;
import com.querydsl.core.types.PathMetadata;
import com.querydsl.core.types.dsl.EntityPathBase;
import com.querydsl.core.types.dsl.NumberPath;
import com.querydsl.core.types.dsl.StringPath;

import javax.annotation.Generated;

import static com.querydsl.core.types.PathMetadataFactory.forVariable;


/**
 * QDeliveryPlace is a Querydsl query type for DeliveryPlace
 */
@Generated("com.querydsl.codegen.EntitySerializer")
public class QDeliveryPlace extends EntityPathBase<DeliveryPlace> {

    private static final long serialVersionUID = 2145510489L;

    public static final QDeliveryPlace deliveryPlace = new QDeliveryPlace("deliveryPlace");

    public final StringPath address = createString("address");

    public final NumberPath<Long> deliveryPlaceId = createNumber("deliveryPlaceId", Long.class);

    public final NumberPath<Double> latitude = createNumber("latitude", Double.class);

    public final NumberPath<Double> longitude = createNumber("longitude", Double.class);

    public final StringPath remark = createString("remark");

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public QDeliveryPlace(String variable) {
        super(DeliveryPlace.class, forVariable(variable));
    }

    public QDeliveryPlace(Path<? extends DeliveryPlace> path) {
        super(path.getType(), path.getMetadata());
    }

    public QDeliveryPlace(PathMetadata metadata) {
        super(DeliveryPlace.class, metadata);
    }

}

