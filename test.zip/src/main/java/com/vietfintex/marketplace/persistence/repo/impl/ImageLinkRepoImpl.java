package com.vietfintex.marketplace.persistence.repo.impl;

public class ImageLinkRepoImpl  {
}
