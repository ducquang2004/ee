package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.web.dto.AdvertisementDTO;

import java.util.List;

public interface AdvertisementCustomRepo {
    List<AdvertisementDTO> getAdvertisement();
}
