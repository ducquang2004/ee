package com.vietfintex.marketplace.persistence.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "division")
public class Division implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "division_id")
    private Long divisionId;
    @Basic(optional = false)
    @Column(name = "division_type")
    private Long divisionType;
    @Basic(optional = false)
    @Column(name = "division_value")
    private Long divisionValue;
    @Basic(optional = false)
    @Column(name = "division_name")
    private String divisionName;

    public Long getDivisionId() {
        return divisionId;
    }

    public void setDivisionId(Long divisionId) {
        this.divisionId = divisionId;
    }

    public Long getDivisionType() {
        return divisionType;
    }

    public void setDivisionType(Long divisionType) {
        this.divisionType = divisionType;
    }

    public Long getDivisionValue() {
        return divisionValue;
    }

    public void setDivisionValue(Long divisionValue) {
        this.divisionValue = divisionValue;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (divisionId != null ? divisionId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GroupClub)) {
            return false;
        }
        Division other = (Division) object;
        if ((this.divisionId == null && other.divisionId != null) || (this.divisionId != null && !this.divisionId.equals(other.divisionId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.vietfintex.marketplace.model.Division[ divisionId=" + divisionId + " ]";
    }

}
