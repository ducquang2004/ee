package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.UserRate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRateRepo extends JpaRepository<UserRate,Long> {
}
