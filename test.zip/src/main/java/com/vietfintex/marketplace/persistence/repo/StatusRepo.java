package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StatusRepo extends JpaRepository<Status, Long> {
    List<Status> findByType(String type);
}
