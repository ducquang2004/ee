package com.vietfintex.marketplace.persistence.repo.impl;

import com.vietfintex.marketplace.persistence.model.ProductOption;
import com.vietfintex.marketplace.persistence.repo.OrderCustomRepo;
import com.vietfintex.marketplace.web.dto.OrderDTO;
import org.springframework.data.domain.Pageable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.Objects.isNull;

public class OrderRepoImpl implements OrderCustomRepo {
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<OrderDTO> search(OrderDTO searchDTO, Pageable pageable) {
        if (isNull(searchDTO)) {
            return null;
        }
        Map<String, Object> param = new HashMap<>();
        String sql = "SELECT * FROM order_table p WHERE 1=1 ";
//        if (!isEmpty(searchDTO.getOptionName())) {
//            sql += " AND p.option_name like CONCAT('%',:optionName,'%')";
//            param.put("optionName", searchDTO.getOptionName());
//        }
//        if (!isEmpty(searchDTO.getDescription())) {
//            sql += " AND p.description like CONCAT('%',:description,'%')";
//            param.put("description", searchDTO.getDescription());
//        }
//        if (nonNull(searchDTO.getStoreId())) {
//            sql += " AND p.store_id = :storeId ";
//            param.put("storeId", searchDTO.getStoreId());
//        }
//        if (!isEmpty(searchDTO.getStatus())) {
//            sql += " AND p.status = :status";
//            param.put("status", searchDTO.getStatus());
//        }
        Query query = em.createNativeQuery(sql, ProductOption.class);
        param.forEach(query::setParameter);
        query.setFirstResult(pageable.getPageNumber());
        query.setMaxResults(pageable.getPageSize());
        return query.getResultList();
    }


    @Override
    public Long count(OrderDTO searchDTO) {
        return null;
    }
}
