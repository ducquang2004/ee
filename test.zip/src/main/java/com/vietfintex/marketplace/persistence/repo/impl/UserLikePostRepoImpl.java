package com.vietfintex.marketplace.persistence.repo.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.vietfintex.marketplace.persistence.repo.UserLikePostCustomRepo;

public class UserLikePostRepoImpl implements UserLikePostCustomRepo {
    @PersistenceContext
    private EntityManager em;

}
