package com.vietfintex.marketplace.persistence.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "global_feature")
public class GlobalFeature implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "global_feature_id")
    private Long globalFeatureId;

    @Basic(optional = false)
    @Column(name = "category_id")
    private Long categoryId;

    @Basic(optional = false)
    @Column(name = "value_key")
    private String valueKey;

    public Long getGlobalFeatureId() {
        return globalFeatureId;
    }

    public void setGlobalFeatureId(Long globalFeatureId) {
        this.globalFeatureId = globalFeatureId;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getValueKey() {
        return valueKey;
    }

    public void setValueKey(String valueKey) {
        this.valueKey = valueKey;
    }
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (globalFeatureId != null ? globalFeatureId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GroupClub)) {
            return false;
        }
        GlobalFeature other = (GlobalFeature) object;
        if (this.globalFeatureId == null && other.globalFeatureId != null) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.vietfintex.marketplace.model.GlobalFeature[ globalFeatureId=" + globalFeatureId + " ]";
    }

}
