package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.ProductFeature;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductFeatureRepo extends JpaRepository<ProductFeature, Long>, ProductFeatureCustomRepo {
    void deleteByProductId(Long productId);
}
