package com.vietfintex.marketplace.persistence.repo;

import java.util.List;

public interface GlobalFeatureCustomRepo {
    List<Long> getParentCategory(Long categoryId);
}
