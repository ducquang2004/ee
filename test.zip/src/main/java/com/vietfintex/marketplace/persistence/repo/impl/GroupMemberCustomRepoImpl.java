package com.vietfintex.marketplace.persistence.repo.impl;

import com.vietfintex.marketplace.persistence.model.GroupMember;
import com.vietfintex.marketplace.persistence.repo.GroupMemberCustomRepo;
import com.vietfintex.marketplace.util.NumberUtils;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.vietfintex.marketplace.util.NumberUtils.convertToLong;
import static java.util.Objects.isNull;

public class GroupMemberCustomRepoImpl implements GroupMemberCustomRepo {
    @PersistenceContext
    private EntityManager em;

    @Override
    public GroupMember findGroupMemberByGroupUser(Long groupMemberId,Long groupId, Long userId) {
        Map<String, Object> param = new HashMap<>();
        String sql = "SELECT * FROM group_member gm WHERE 1=1 ";

        if(groupMemberId != null){
            sql += " AND gm.group_member_id = :groupMemberId";
            param.put("groupMemberId",groupMemberId);
        }

        if(groupId != null){
            sql += " AND gm.group_id = :groupId ";
            param.put("groupId",groupId);
        }
        if (userId != null){
            sql += "AND gm.user_id = :userId";
            param.put("userId",userId);
        }
        Query query = em.createNativeQuery(sql,GroupMember.class);
        param.forEach(query::setParameter);
        List<GroupMember> result = query.getResultList();
        if(result.size() > 0){
            return result.get(0);
        }else{
            return  null;
        }
    }

    @Override
    public Long getMemberCountByGroupId(long groupId) {
        Map<String, Object> param = new HashMap<>();
        String sql = "SELECT count(1) from group_member gm WHERE gm.group_id = :groupId";
        param.put("groupId",groupId);
        Query query = em.createNativeQuery(sql);
        param.forEach(query::setParameter);
        return convertToLong(query.getSingleResult());
    }

    @Override
    public List<Long> getUserMemberList(List<Long> userList, Long groupId) {
        String sql = "SELECT g.user_id FROM group_member g WHERE g.user_id in ("
                + StringUtils.join(userList, ',') +")  AND g.group_id = " + groupId;
        Query query = em.createNativeQuery(sql);
        List<Object[]> lst = query.getResultList();
        List<Long> returnList = new ArrayList<>();
        if(isNull(lst)){
            return null;
        }
        for (Object obj: lst) {
            returnList.add(NumberUtils.convertToLong(obj));
        }
        return returnList;
    }
}
