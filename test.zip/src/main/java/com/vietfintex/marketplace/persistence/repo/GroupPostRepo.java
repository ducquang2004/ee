package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.GroupPost;
import org.springframework.data.jpa.repository.JpaRepository;


public interface GroupPostRepo extends JpaRepository<GroupPost,Long>, GroupPostCustomRepo {
    }
