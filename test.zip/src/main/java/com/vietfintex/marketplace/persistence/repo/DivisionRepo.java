package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.Division;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DivisionRepo extends JpaRepository<Division,Long> {
    List<Division> getByDivisionType(Long divisionType);
}
