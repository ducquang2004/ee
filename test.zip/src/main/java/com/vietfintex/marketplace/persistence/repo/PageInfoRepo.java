package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.PageInfo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PageInfoRepo extends JpaRepository<PageInfo,Long>{
}
