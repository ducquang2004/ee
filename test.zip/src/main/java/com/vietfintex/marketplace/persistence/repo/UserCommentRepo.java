package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.UserComment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserCommentRepo extends JpaRepository<UserComment,Long> {
}
