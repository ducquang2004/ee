package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.web.dto.InvitationGetDTO;

import java.util.List;

public interface InvitationCustomRepo {
    List<InvitationGetDTO> getInvitationGetByUser(Long userId, String status, int startPage);
}
