package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.CommissionGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.lang.Nullable;

import java.util.List;

public interface CommissionGroupRepo extends JpaRepository<CommissionGroup, Long> {
    CommissionGroup getByGroupId(Long groupId);
}
