package com.vietfintex.marketplace.persistence.repo.impl;

import com.vietfintex.marketplace.persistence.repo.InvitationCustomRepo;
import com.vietfintex.marketplace.util.GlobalUtil;
import com.vietfintex.marketplace.util.NumberUtils;
import com.vietfintex.marketplace.web.dto.GroupClubDTO;
import com.vietfintex.marketplace.web.dto.InvitationDTO;
import com.vietfintex.marketplace.web.dto.InvitationGetDTO;
import com.vietfintex.marketplace.web.dto.UserDTO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.isNull;

public class InvitationCustomRepoImpl implements InvitationCustomRepo {
    @PersistenceContext
    private EntityManager em;
    @Override
    public List<InvitationGetDTO> getInvitationGetByUser(Long userId, String status, int startPage) {
        String sql = "SELECT i.invitation_id, i.user_id, i.group_id, i.invitation_content, "
                +" i.invited_date, i.expired_date, i.invite_user_id, i.user_phone, "
                +" i.user_mail, i.status, i.access_key,g.group_name, g.owner_id, "
                +" g.clubDescription, g.annual_fee, g.status as groupStatus, g.privacy, "
                +" g.term, g.member_count, u.user_id as userId, u.email, u.phone, u.firstname FROM invitation i INNER JOIN group_club g ON "
                +" i.group_id = g.group_id INNER JOIN user u ON i.user_id = u.user_id "
                +" WHERE i.user_id = "+userId+ " AND i.status = '"+status+"'";
        Query query = em.createNativeQuery(sql);
        query.setFirstResult(startPage);
        query.setMaxResults(10);
        List<Object[]> lst = query.getResultList();
        List<InvitationGetDTO> returnList = new ArrayList<>();
        if(isNull(lst)){
            return null;
        }
        int i;
        for (Object[] obj: lst) {
            i = 0;
            InvitationGetDTO invitationGetDTO = new InvitationGetDTO();
            InvitationDTO invitationDTO = new InvitationDTO();
            GroupClubDTO groupClubDTO = new GroupClubDTO();
            UserDTO userDTO = new UserDTO();
            invitationDTO.setInvitationId(NumberUtils.convertToLong(obj[i++]));
            invitationDTO.setUserId(NumberUtils.convertToLong(obj[i++]));
            invitationDTO.setGroupId(NumberUtils.convertToLong(obj[i++]));
            invitationDTO.setInvitationContent(GlobalUtil.convertToString(obj[i++]));
            invitationDTO.setInvitedDate(GlobalUtil.convertObjectToDate(obj[i++]));
            invitationDTO.setExpiredDate(GlobalUtil.convertObjectToDate(obj[i++]));
            invitationDTO.setInviteUserId(NumberUtils.convertToLong(obj[i++]));
            invitationDTO.setUserPhone(GlobalUtil.convertToString(obj[i++]));
            invitationDTO.setUserMail(GlobalUtil.convertToString(obj[i++]));
            invitationDTO.setStatus(GlobalUtil.convertToString(obj[i++]));
            invitationDTO.setAccessKey(GlobalUtil.convertToString(obj[i++]));
            groupClubDTO.setGroupId(invitationDTO.getGroupId());
            groupClubDTO.setGroupName(GlobalUtil.convertToString(obj[i++]));
            groupClubDTO.setOwnerId(NumberUtils.convertToLong(obj[i++]));
            groupClubDTO.setClubDescription(GlobalUtil.convertToString(obj[i++]));
            groupClubDTO.setAnnualFee(NumberUtils.convertToDouble(obj[i++]));
            groupClubDTO.setStatus(GlobalUtil.convertToString(obj[i++]));
            groupClubDTO.setPrivacy(GlobalUtil.convertToString(obj[i++]));
            groupClubDTO.setTerm(GlobalUtil.convertToString(obj[i++]));
            groupClubDTO.setMemberCount(NumberUtils.convertToLong(obj[i++]));
            userDTO.setUserId(NumberUtils.convertToLong(obj[i++]));
            userDTO.setEmail(GlobalUtil.convertToString(obj[i++]));
            userDTO.setPhone(GlobalUtil.convertToString(obj[i++]));
            userDTO.setFirstname(GlobalUtil.convertToString(obj[i++]));
            invitationGetDTO.setGroupClubDTO(groupClubDTO);
            invitationGetDTO.setInvitationDTO(invitationDTO);
            invitationGetDTO.setUserDTO(userDTO);
            returnList.add(invitationGetDTO);
        }
        return returnList;
    }
}
