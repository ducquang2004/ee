package com.vietfintex.marketplace.persistence.repo.impl;

import com.vietfintex.marketplace.persistence.repo.GlobalFeatureCustomRepo;
import com.vietfintex.marketplace.util.NumberUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.isNull;

public class GlobalFeatureRepoImpl implements GlobalFeatureCustomRepo {
    @PersistenceContext
    private EntityManager em;
    @Override
    public List<Long> getParentCategory(Long categoryId) {
        String sql = "SELECT category.parent_category_id FROM category "
                +" WHERE category_id = "+ categoryId
                +" UNION  SELECT category.parent_category_id FROM category "
                +" WHERE category_id IN (SELECT parent_category_id FROM category WHERE  "
                +"  category_id = "+categoryId+"  ) UNION SELECT "+categoryId+"  categoryID ";
        Query query = em.createNativeQuery(sql);
        List<Object> lst = query.getResultList();
        List<Long> returnList = new ArrayList<>();
        if(isNull(lst)){
            return null;
        }
        for (Object obj: lst) {
            returnList.add(NumberUtils.convertToLong(obj));
        }
        return returnList;
    }
}
