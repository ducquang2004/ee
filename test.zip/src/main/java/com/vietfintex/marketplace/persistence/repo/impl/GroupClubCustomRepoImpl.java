package com.vietfintex.marketplace.persistence.repo.impl;

import com.vietfintex.marketplace.persistence.model.GroupClub;
import com.vietfintex.marketplace.persistence.repo.GroupClubCustomRepo;
import com.vietfintex.marketplace.util.GlobalUtil;
import com.vietfintex.marketplace.util.NumberUtils;
import com.vietfintex.marketplace.web.dto.GroupClubDTO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.Objects.isNull;

public class GroupClubCustomRepoImpl implements GroupClubCustomRepo {
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<GroupClub> getListGroupClub(Long groupId, String privacy, String keyword,Long ownerId,Integer page) {
        String sql= "SELECT g.* FROM group_club g WHERE 1= 1 ";
        Map<String, Object> param = new HashMap<>();
        if(groupId!= null){
            sql += " AND g.group_id = :groupId ";
            param.put("groupId",groupId);
        }
        if (privacy != null &&!"".equals(privacy)){
            sql  += " AND g.privacy= :privacy ";
            param.put("privacy",privacy);
        }
        if(keyword != null &&!"".equals(keyword)){
            sql += " AND g.group_name like CONCAT('%',:keyword,'%') ";
            param.put("keyword",keyword);
        }
        if(ownerId != null){
            sql += " AND g.owner_id = :ownerId";
            param.put("ownerId",ownerId);
        }
        Query query = em.createNativeQuery(sql, GroupClub.class);
        query.setMaxResults(10);
        if(page!=null){
            query.setFirstResult(page);
        }
        param.forEach(query::setParameter);

        return query.getResultList();
    }

    @Override
    public List<GroupClub> getListOtherGroupClub(Long groupId, String privacy, String keyword, Long ownerId,Integer page) {
        String sql= "SELECT g.* FROM group_club g WHERE 1= 1 ";
        Map<String, Object> param = new HashMap<>();
        if(groupId!= null){
            sql += " AND g.group_id = :groupId ";
            param.put("groupId",groupId);
        }
        if (privacy != null &&!"".equals(privacy)){
            sql  += " AND g.privacy= :privacy ";
            param.put("privacy",privacy);
        }
        if(keyword != null &&!"".equals(keyword)){
            sql += " AND g.group_name like CONCAT('%',:keyword,'%') ";
            param.put("keyword",keyword);
        }
        if(ownerId != null){
            sql += " AND g.owner_id <> :ownerId";
            param.put("ownerId",ownerId);
        }
        Query query = em.createNativeQuery(sql, GroupClub.class);
        query.setMaxResults(10);
        if(page!=null){
            query.setFirstResult(page);
        }
        param.forEach(query::setParameter);

        return query.getResultList();
    }

    @Override
    public List<GroupClubDTO> getJoinedClub(Long userId, int startResult,String keyWord) {
        String sql = "SELECT g.group_id, g.group_name, g.owner_id, g.clubDescription, "
                + " g.annual_fee, g.status, g.privacy, g.term, g.access_key, "
                + " g.member_count FROM group_club g INNER JOIN group_member gm ON g.group_id  "
                + " = gm.group_id WHERE gm.user_id = " + userId
                +" AND g.owner_id <> " + userId;
        if (keyWord != null && keyWord != ""){
            sql += " AND g.group_name like N'%"+ keyWord + "%'";
        }
        Query query = em.createNativeQuery(sql);
        query.setMaxResults(10);
        query.setFirstResult(startResult);

        List<Object[]> lst = query.getResultList();
        List<GroupClubDTO> returnList = new ArrayList<>();
        if(isNull(lst)){
            return null;
        }
        int i;
        for (Object[] obj: lst) {
            i = 0;
            GroupClubDTO categoryDTO = new GroupClubDTO();
            categoryDTO.setGroupId(NumberUtils.convertToLong(obj[i++]));
            categoryDTO.setGroupName(GlobalUtil.convertToString(obj[i++]));
            categoryDTO.setOwnerId(NumberUtils.convertToLong(obj[i++]));
            categoryDTO.setClubDescription(GlobalUtil.convertToString(obj[i++]));
            categoryDTO.setAnnualFee(NumberUtils.convertToDouble(obj[i++]));
            categoryDTO.setStatus(GlobalUtil.convertToString(obj[i++]));
            categoryDTO.setPrivacy(GlobalUtil.convertToString(obj[i++]));
            categoryDTO.setTerm(GlobalUtil.convertToString(obj[i++]));
            categoryDTO.setAccessKey(NumberUtils.convertToString(obj[i++]));
            categoryDTO.setMemberCount(NumberUtils.convertToLong(obj[i++]));
            returnList.add(categoryDTO);
        }
        return returnList;
    }
}
