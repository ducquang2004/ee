package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.GroupMember;

import java.util.List;

public interface GroupMemberCustomRepo {
    GroupMember findGroupMemberByGroupUser(Long groupMemberId, Long groupId, Long userId);
    Long getMemberCountByGroupId(long groupId);
    List<Long> getUserMemberList(List<Long> userList, Long groupId);
}
