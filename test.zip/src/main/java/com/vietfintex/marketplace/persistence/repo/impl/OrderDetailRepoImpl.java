package com.vietfintex.marketplace.persistence.repo.impl;

import com.vietfintex.marketplace.persistence.model.*;
import com.vietfintex.marketplace.persistence.repo.*;
import com.vietfintex.marketplace.util.GlobalUtil;
import com.vietfintex.marketplace.util.NumberUtils;
import com.vietfintex.marketplace.web.dto.*;
import com.vietfintex.marketplace.web.service.OrderDetailService;
import com.vietfintex.marketplace.web.service.ProductOptionMService;
import com.vietfintex.marketplace.web.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.vietfintex.marketplace.util.NumberUtils.convertToLong;
import static java.util.Objects.isNull;

public class OrderDetailRepoImpl implements OrderDetailCustomRepo {
    @PersistenceContext
    private EntityManager em;
    @Autowired
    private ProductOptionMService productOptionMService;
    @Autowired
    ProductService productService;
    @Autowired
    GroupPostRepo groupPostRepo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    CommissionGroupRepo commissionGroupRepo;
    @Autowired
    GroupMemberRepo groupMemberRepo;
    @Autowired
    OrderDetailService orderDetailService;

    @Override
    public List<OrderDetailDTO> search(OrderDetailDTO searchDTO, int startPage, int pageSize) {
        if (isNull(searchDTO)) {
            return null;
        }
        Map<String, Object> param = new HashMap<>();
        String sql = "SELECT * FROM order_table p WHERE 1=1 ";
        Query query = em.createNativeQuery(sql, OrderDetail.class);
        param.forEach(query::setParameter);
        query.setFirstResult(startPage);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }


    @Override
    public List<OrderDetailWrapDTO> getOrderByUserId(Long userId,Long deliveryStatus, int startPage, Long productOwnerId) {
        HashMap<String, Object> param = new HashMap();
        String sql = "SELECT od.item_id itemId, od.order_id orderId, od.product_id productId, od.list_price  "
                + " listPrice, od.price price, od.quantity quantity, od.product_code productCode, COALESCE "
                +" (od.deliver_place_id ,ot.delivery_place_id) deliverPlaceId, od.delivery_status deliveryStatus, COALESCE "
                +" (od.shipping_cost,ot.shipping_cost )shippingCost, COALESCE (od.remark, ot.remark) remark, "
                +" od.user_id userId, COALESCE (od.create_time, ot.created_time) createdTime, COALESCE  "
                +" (od.delivered_time, ot.delivered_time) deliveredTime, COALESCE (od.expected_delivery_time, "
                +" ot.expected_delivery_time) expectedDeliveryTime, ot.store_id storeId, p.product_name, od.product_option_id FROM "
                +" order_detail od INNER JOIN order_table ot ON od.order_id = ot.order_id INNER JOIN product "
                +" p ON p.product_id = od.product_id WHERE 1 "
                +" AND od.delivery_status =:deliveryStatus ";
                param.put("deliveryStatus",deliveryStatus);
                if (userId != null){
                   sql +=  " AND od.user_id =:userId ";
                   param.put("userId",userId);
                }
                if (productOwnerId != null){
                    sql +=  " AND p.product_owner_id =:productOwnerId ";
                    param.put("productOwnerId",productOwnerId);
                }
                sql += " ORDER BY od.delivery_status AND od.create_time";
        Query query = em.createNativeQuery(sql);
        query.setFirstResult(startPage);
        query.setMaxResults(10);
        param.forEach(query::setParameter);
        List<Object[]> lst = query.getResultList();
        List<OrderDetailWrapDTO> returnList = new ArrayList<>();
        if(isNull(lst)){
            return null;
        }
        int i;
        List<Long> productOptionList = new ArrayList<>();
        for (Object[] obj: lst) {
            i = 0;
            OrderDetailWrapDTO orderDetailWrapDTO = new OrderDetailWrapDTO();
            orderDetailWrapDTO.setItemId(NumberUtils.convertToLong(obj[i++]));
            orderDetailWrapDTO.setOrderId(NumberUtils.convertToLong(obj[i++]));
            orderDetailWrapDTO.setProductId(NumberUtils.convertToLong(obj[i++]));
            orderDetailWrapDTO.setListPrice(NumberUtils.convertToDouble(obj[i++]));
            orderDetailWrapDTO.setPrice(NumberUtils.convertToDouble(obj[i++]));
            orderDetailWrapDTO.setQuantity((Integer)obj[i++]);
            orderDetailWrapDTO.setProductCode(GlobalUtil.convertToString(obj[i++]));
            orderDetailWrapDTO.setDeliverPlaceId(NumberUtils.convertToLong(obj[i++]));
            orderDetailWrapDTO.setDeliveryStatus(NumberUtils.convertToLong(obj[i++]));
            orderDetailWrapDTO.setShippingCost(NumberUtils.convertToDouble(obj[i++]));
            orderDetailWrapDTO.setRemark(GlobalUtil.convertToString(obj[i++]));
            orderDetailWrapDTO.setUserId(NumberUtils.convertToLong(obj[i++]));
            orderDetailWrapDTO.setCreateTime(GlobalUtil.convertObjectToDate(obj[i++]));
            orderDetailWrapDTO.setDeliveredTime(GlobalUtil.convertObjectToDate(obj[i++]));
            orderDetailWrapDTO.setExpectedDeliveryTime(GlobalUtil.convertObjectToDate(obj[i++]));
            orderDetailWrapDTO.setStoreId(NumberUtils.convertToLong(obj[i++]));
            orderDetailWrapDTO.setProductName(GlobalUtil.convertToString(obj[i++]));
            Long productOptionId = NumberUtils.convertToLong(obj[i]);
            if (productOptionId != null){
                orderDetailWrapDTO.setProductOptionId(productOptionId);
                productOptionList.add(productOptionId);
            }
            returnList.add(orderDetailWrapDTO);
        }
        if (productOptionList.size() > 0) {
            List<ProductOptionMDTO> productOptionDTOList = productOptionMService.getByProductKindIdIn(productOptionList);
            for (int j = 0 ;j < returnList.size();j++){
                OrderDetailWrapDTO item = returnList.get(j);
                if (item.getProductOptionId() != null) {
                    for (ProductOptionMDTO productOptionMDTO : productOptionDTOList) {
                        if (item.getProductOptionId() == productOptionMDTO.getProductKindId()){
                            item.setProductOption(productOptionMDTO);
                            returnList.set(j,item);
                        }
                    }
                }
            }
        }
        return returnList;
    }

    @Override
    public Long count(OrderDetailDTO searchDTO) {
        if (isNull(searchDTO)) {
            return null;
        }
        Map<String, Object> param = new HashMap<>();
        String sql = "SELECT * FROM product_option p WHERE 1=1 ";
        Query query = em.createNativeQuery(sql);
        param.forEach(query::setParameter);
        return convertToLong(query.getSingleResult());
    }
    @Transactional
    public OrderDetailDTO completeOrder(OrderDetailDTO orderDetailDTO) {
        ProductDTO productDTO = productService.findOne(orderDetailDTO.getProductId());
        HashMap<String,Object> param = new HashMap<>();
        if (productDTO != null){
            GroupPost groupPost = null;
            String sql = "SELECT gp.* FROM group_post gp WHERE gp.product_id =:productId ";
            param.put("productId",orderDetailDTO.getProductId());
            if (productDTO.getStoreId() != null){
                sql += " AND gp.store_id=:storeId ";
                param.put("storeId",productDTO.getStoreId());
            }
            if (productDTO.getStoreCategoryId() != null){
                sql += " AND gp.category_store_id =:categoryStoreId ";
                param.put("categoryStoreId",productDTO.getStoreCategoryId());
            }
            Query query = em.createNativeQuery(sql,GroupPost.class);
            param.forEach(query::setParameter);
            query.setMaxResults(1);
            List<Object> list = query.getResultList();
            if (list != null && list.size() > 0){
                groupPost = (GroupPost) list.get(0);
            }
            if (groupPost == null)
                groupPost = new GroupPost();
//            GroupPost groupPost = groupPostRepo.getByProductIdAndStoreIdAndAndCategoryStoreIdOOrderByStartDate(productDTO.getProductId(),
//                    productDTO.getStoreId(), productDTO.getStoreCategoryId());
            //Lay so tien chiet khau khi mua san pham.
            //Neu chiet khau theo % thi lay so tien ban dc nhan % chiet khau
            Double bonus = groupPost.getDiscountPrice() != null ? groupPost.getDiscountPrice()
                    : (groupPost.getDiscountPercent() / 100 * orderDetailDTO.getPrice());
            //Lay thong tin triet khau cua hoi nhom do.
            CommissionGroup commissionGroup = commissionGroupRepo.getByGroupId(groupPost.getGroupId());
            //% mac dinh. SmileTech dc 20%
            //# tai khoan con lai 80%
            //Cac gia tri ownerPercent, buyerPercent, parentBuyerPercenr chia nhau 80% con lai
            Double ownerGroupPercent = 30D, buyerPercent = 40D, parentBuyerPercent = 30D , smileTechPercent = 20D;
            if (commissionGroup != null){
                if (commissionGroup.getOwnerGroupPercent()!= null){
                    ownerGroupPercent = commissionGroup.getOwnerGroupPercent();
                }
                if (commissionGroup.getBuyerPercent()!= null){
                    buyerPercent = commissionGroup.getBuyerPercent();
                }
                if (commissionGroup.getParentBuyerPercent()!= null){
                    parentBuyerPercent = commissionGroup.getParentBuyerPercent();
                }
                if (commissionGroup.getParentBuyerPercent()!= null){
                    smileTechPercent = commissionGroup.getSmileTechPercent();
                }
            }
            Double remainBonus = bonus* (1- smileTechPercent/100);
            //Lay thong tin chu hoi nhom
            List<User> needUpdate = new ArrayList<>();
            User ownerGroup = userRepo.getGroupOwnerByGroupId(groupPost.getGroupId());
            ownerGroup.setCoin((ownerGroup.getCoin() != null ?ownerGroup.getCoin() : 0 ) + remainBonus * ownerGroupPercent /100);
            needUpdate.add(ownerGroup);

            //Lay thong tin parent user id
            GroupMember groupMember = groupMemberRepo.getByGroupIdAndUserId(groupPost.getGroupId(),orderDetailDTO.getUserId());
            if (groupMember != null && groupMember.getParentUserId() != null){
                User parentBuyer = userRepo.getOne(groupMember.getParentUserId());
                if (parentBuyer != null){ //Tim thay thong tin parent buy
                    parentBuyer.setCoin((parentBuyer.getCoin() != null ?parentBuyer.getCoin() : 0 ) + remainBonus * parentBuyerPercent /100);
                    needUpdate.add(parentBuyer);
                }else{ //Truong hop k tim thay thi + % parent cho nguoi mua
                    buyerPercent += parentBuyerPercent;
                }
            }else{ //Truong hop k tim thay thi + % parent cho nguoi mua
                buyerPercent += parentBuyerPercent;
            }
            User buyer = userRepo.getOne(orderDetailDTO.getUserId());
            buyer.setCoin((buyer.getCoin() != null ?buyer.getCoin() : 0 )+ remainBonus * buyerPercent /100);
            needUpdate.add(buyer);
            //Cap nhat lai coin
            userRepo.saveAll(needUpdate);
            //Cap nhat lai trang thai don hang 5: Đã hoàn thành
            sql = "UPDATE order_detail od set od.delivery_status = 5 WHERE od.item_id = "+orderDetailDTO.getItemId();
            query  = em.createNativeQuery(sql);
            query.executeUpdate();
            orderDetailDTO.setDeliveryStatus(5);
            return orderDetailDTO;
        }
        return null;
    }
}
