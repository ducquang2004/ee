package com.vietfintex.marketplace.persistence.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "invitation")
public class Invitation  implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "invitation_id")
    private Long invitationId;

    @Basic(optional = false)
    @Column(name = "user_id")
    private Long userId ;

    @Basic(optional = false)
    @Column(name = "group_id")
    private Long groupId;

    @Column(name = "invitation_content")
    private String invitationContent ;

    @Column(name = " invited_date")
    private Date invitedDate;

    @Column(name = "expired_date")
    private Date expiredDate;

    @Basic(optional = false)
    @Column(name = "invite_user_id")
    private Long inviteUserId;

    @Column(name = "user_phone")
    private String userPhone;

    @Column(name = "user_mail")
    private String userMail;

    @Column(name = "status")
    private String status;

    @Column(name = "access_key")
    private String accessKey ;

    public Long getInvitationId() {
        return invitationId;
    }

    public void setInvitationId(Long invitationId) {
        this.invitationId = invitationId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public String getInvitationContent() {
        return invitationContent;
    }

    public void setInvitationContent(String invitationContent) {
        this.invitationContent = invitationContent;
    }

    public Date getInvitedDate() {
        return invitedDate;
    }

    public void setInvitedDate(Date invitedDate) {
        this.invitedDate = invitedDate;
    }

    public Date getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Date expiredDate) {
        this.expiredDate = expiredDate;
    }

    public Long getInviteUserId() {
        return inviteUserId;
    }

    public void setInviteUserId(Long inviteUserId) {
        this.inviteUserId = inviteUserId;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getUserMail() {
        return userMail;
    }

    public void setUserMail(String userMail) {
        this.userMail = userMail;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (invitationId != null ? invitationId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Image)) {
            return false;
        }
        Invitation other = (Invitation) object;
        if ((this.invitationId == null && other.invitationId != null) || (this.invitationId != null && !this.invitationId.equals(other.invitationId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.vietfintex.marketplace.model.Invitation[ invitationId=" + invitationId + " ]";
    }

}
