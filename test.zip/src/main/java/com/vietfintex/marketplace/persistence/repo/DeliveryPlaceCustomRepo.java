package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.web.dto.DeliveryPlaceDTO;

import java.util.List;

public interface DeliveryPlaceCustomRepo {
    List<DeliveryPlaceDTO> getDeliveryList(Integer startResult, Integer maxResult, DeliveryPlaceDTO deliveryPlaceDTO);
}
