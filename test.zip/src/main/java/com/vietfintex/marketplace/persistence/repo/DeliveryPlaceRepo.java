package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.DeliveryPlace;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeliveryPlaceRepo  extends JpaRepository<DeliveryPlace, Long>, DeliveryPlaceCustomRepo {

}
