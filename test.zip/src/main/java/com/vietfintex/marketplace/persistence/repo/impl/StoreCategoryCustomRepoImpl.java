package com.vietfintex.marketplace.persistence.repo.impl;

import com.vietfintex.marketplace.persistence.model.StoreCategory;
import com.vietfintex.marketplace.persistence.repo.StoreCategoryCustomRepo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

public class StoreCategoryCustomRepoImpl implements StoreCategoryCustomRepo {
    @PersistenceContext
    private EntityManager em;

    @Override
    public void storeCategoryChange(long storeId, List<Long> categoryIdList) {
        String sql = "INSERT INTO store_category (store_id,category_id,status) values ";
        for (Long categoryId :categoryIdList){
            sql += "("+storeId+","+categoryId+","+"'A'),";
        }
        sql = sql.substring(0, sql.length() - 1);
        Query query = em.createNativeQuery(sql);
        int i = query.executeUpdate();
        return;
    }

    @Override
    public StoreCategory getStoreCategoryInfo(long storeCategoryId, long userId) {
        String sql = "SELECT sc.* FROM store_category sc INNER JOIN store s ON sc.store_id = s.store_id  "
                + " WHERE s.owner_id =  "+userId +" AND sc.store_category_id = " +storeCategoryId;
        Query query = em.createNativeQuery(sql,StoreCategory.class);
        query.setMaxResults(1);
        List<Object> list = query.getResultList();
        if (list == null || list.size() == 0){
            return null;
        }
        return (StoreCategory) list.get(0);
    }
}
