/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vietfintex.marketplace.persistence.model;

import javax.persistence.*;
import java.io.Serializable;

/**
 *
 * @author Dell
 */
@Entity
@Table(name = "product_feature")
public class ProductFeature implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "feature_id")
    private Long featureId;
    @Column(name = "global_feature_id")
    private Long globalFeatureId;
    @Column(name = "category_id")
    private String categoryId;
    @Lob
    @Column(name = "full_description")
    private String fullDescription;
    @Basic(optional = false)
    @Column(name = "product_id")
    private Long productId;


    public ProductFeature() {
    }

    public ProductFeature(Long featureId) {
        this.featureId = featureId;
    }

    public Long getFeatureId() {
        return featureId;
    }

    public void setFeatureId(Long featureId) {
        this.featureId = featureId;
    }

    public Long getGlobalFeatureId() {
        return globalFeatureId;
    }

    public void setGlobalFeatureId(Long globalFeatureId) {
        this.globalFeatureId = globalFeatureId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getFullDescription() {
        return fullDescription;
    }

    public void setFullDescription(String fullDescription) {
        this.fullDescription = fullDescription;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (featureId != null ? featureId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProductFeature)) {
            return false;
        }
        ProductFeature other = (ProductFeature) object;
        if ((this.featureId == null && other.featureId != null) || (this.featureId != null && !this.featureId.equals(other.featureId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.vietfintex.marketplace.model.ProductFeature[ featureId=" + featureId + " ]";
    }
    
}
