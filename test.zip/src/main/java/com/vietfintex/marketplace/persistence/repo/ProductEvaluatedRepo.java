package com.vietfintex.marketplace.persistence.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vietfintex.marketplace.persistence.model.ProductEvaluated;

public interface ProductEvaluatedRepo extends JpaRepository<ProductEvaluated,Long> {
	List<ProductEvaluated> findAllByObjectTypeAndObjectId(String objectType,Long postId);
}
