package com.vietfintex.marketplace.persistence.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "group_post")
public class GroupPost implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "group_post_id")
    private Long groupPostId;

    @Basic(optional = false)
    @Column(name = "group_id")
    private Long groupId;

    @Column(name = "product_id")
    private Long productId;

    @Column(name = "category_store_id")
    private Long categoryStoreId;

    @Column(name = "store_id")
    private Long storeId;

    @Column(name = "start_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;

    @Column(name = "expired_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date expiredDate;

    @Column(name = "discount_percent")
    private Integer discountPercent;

    @Column(name = "discount_price")
    private Double discountPrice;

    @Basic(optional = false)
    @Column(name = "owner_id")
    private Long ownerId;

    @Basic(optional = false)
    @Column(name = "is_active")
    private Integer isActive;

    @Column(name = "post_type")
    private String postType;

    @Column(name = "full_description")
    private String fullDescription;

    public Long getGroupPostId() {
        return groupPostId;
    }

    public void setGroupPostId(Long groupPostId) {
        this.groupPostId = groupPostId;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getCategoryStoreId() {
        return categoryStoreId;
    }

    public void setCategoryStoreId(Long categoryStoreId) {
        this.categoryStoreId = categoryStoreId;
    }

    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Date expiredDate) {
        this.expiredDate = expiredDate;
    }

    public Integer getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(Integer discountPercent) {
        this.discountPercent = discountPercent;
    }

    public Double getDiscountPrice() {
        return discountPrice;
    }

    public void setDiscountPrice(Double discountPrice) {
        this.discountPrice = discountPrice;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public Integer getIsActive() {
        return isActive;
    }

    public void setIsActive(Integer isActive) {
        this.isActive = isActive;
    }

    public String getFullDescription() {
        return fullDescription;
    }

    public void setFullDescription(String fullDescription) {
        this.fullDescription = fullDescription;
    }

    public String getPostType() {
        return postType;
    }

    public void setPostType(String postType) {
        this.postType = postType;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (groupPostId != null ? groupPostId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GroupClub)) {
            return false;
        }
        GroupPost other = (GroupPost) object;
        if ((this.groupPostId == null && other.groupPostId != null) || (this.groupPostId != null && !this.groupPostId.equals(other.groupPostId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.vietfintex.marketplace.model.GroupPost[ groupPostId=" + groupPostId + " ]";
    }

}
