package com.vietfintex.marketplace.persistence.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the product_evaluated database table.
 * 
 */
@Entity
@Table(name="product_evaluated")
@NamedQuery(name="ProductEvaluated.findAll", query="SELECT p FROM ProductEvaluated p")
public class ProductEvaluated implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Long id;

	@Column(name="comment_count", nullable=false)
	private int commentCount;

	@Column(name="like_count", nullable=false)
	private int likeCount;

	@Column(name="object_id", nullable=false)
	private Long objectId;

	@Column(name="object_type", nullable=false, length=10)
	private String objectType;

	@Column(name="rate_count", nullable=false)
	private int rateCount;

	@Column(name="rate_total", nullable=false)
	private int rateTotal;

	@Column(name="rate_value", nullable=false)
	private float rateValue;

	@Column(name="updated_time", nullable=false)
	private Date updatedTime;

	public ProductEvaluated() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getCommentCount() {
		return this.commentCount;
	}

	public void setCommentCount(int commentCount) {
		this.commentCount = commentCount;
	}

	public int getLikeCount() {
		return this.likeCount;
	}

	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}

	public Long getObjectId() {
		return this.objectId;
	}

	public void setObjectId(Long objectId) {
		this.objectId = objectId;
	}

	public String getObjectType() {
		return this.objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public int getRateCount() {
		return this.rateCount;
	}

	public void setRateCount(int rateCount) {
		this.rateCount = rateCount;
	}

	public int getRateTotal() {
		return this.rateTotal;
	}

	public void setRateTotal(int rateTotal) {
		this.rateTotal = rateTotal;
	}

	public float getRateValue() {
		return this.rateValue;
	}

	public void setRateValue(float rateValue) {
		this.rateValue = rateValue;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

}