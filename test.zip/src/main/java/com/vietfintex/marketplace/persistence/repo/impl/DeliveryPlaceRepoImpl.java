package com.vietfintex.marketplace.persistence.repo.impl;

import com.vietfintex.marketplace.persistence.repo.DeliveryPlaceCustomRepo;
import com.vietfintex.marketplace.util.GlobalUtil;
import com.vietfintex.marketplace.util.NumberUtils;
import com.vietfintex.marketplace.web.dto.DeliveryPlaceDTO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.isNull;

public class DeliveryPlaceRepoImpl implements DeliveryPlaceCustomRepo {
    @PersistenceContext
    private EntityManager em;
    @Override
    public List<DeliveryPlaceDTO> getDeliveryList(Integer startResult, Integer maxResult, DeliveryPlaceDTO deliveryPlaceDTO) {
        String sql= "SELECT dv.delivery_place_id delivery_place_id, dv.user_id user_id, dv.address address, COALESCE (dv.latitude,0.0) latitude, COALESCE (dv.longitude,0.0) longitude, COALESCE (dv.remark,'') remark, dv.contact_phone contacthone, dv.contact_name contactName FROM delivery_place dv WHERE 1= 1 ";
        if(deliveryPlaceDTO.getDeliveryPlaceId()!= null){
            sql += " AND dv.delivery_place_id = " + deliveryPlaceDTO.getDeliveryPlaceId();
        }
        if (deliveryPlaceDTO.getUserId() != null &&!"".equals(deliveryPlaceDTO.getUserId())){
            sql  += " AND dv.user_id = "+deliveryPlaceDTO.getUserId();
        }
        if(deliveryPlaceDTO.getAddress() != null && !"".equals(deliveryPlaceDTO.getAddress())){
            sql +=" AND dv.address like N'%"+deliveryPlaceDTO.getAddress()+"%'";
        }
        if(deliveryPlaceDTO.getContactName() != null && !"".equals(deliveryPlaceDTO.getContactName())){
            sql +=" AND dv.contact_name like N'%"+deliveryPlaceDTO.getContactName()+"%'";
        }
        if(deliveryPlaceDTO.getContactPhone() != null && !"".equals(deliveryPlaceDTO.getContactPhone())){
            sql +=" AND dv.contact_phone like N'%"+deliveryPlaceDTO.getContactPhone()+"%'";
        }
        Query query = em.createNativeQuery(sql);
        if (maxResult != null) {
            query.setMaxResults(maxResult);
        }else{
            query.setMaxResults(10);
        }
        if(startResult!=null){
            query.setFirstResult(startResult);
        }else {
            query.setFirstResult(0);
        }

        List<Object[]> lst = query.getResultList();
        List<DeliveryPlaceDTO> returnList = new ArrayList<>();
        if(isNull(lst)){
            return null;
        }
        int i;
        for (Object[] obj: lst) {
            i = 0;
            DeliveryPlaceDTO deliveryDTO = new DeliveryPlaceDTO();
            deliveryDTO.setDeliveryPlaceId(NumberUtils.convertToLong(obj[i++]));
            deliveryDTO.setUserId(NumberUtils.convertToLong(obj[i++]));
            deliveryDTO.setAddress(GlobalUtil.convertToString(obj[i++]));
            deliveryDTO.setLatitude(NumberUtils.convertToDouble(obj[i++]));
            deliveryDTO.setLongitude(NumberUtils.convertToDouble(obj[i++]));
            deliveryDTO.setRemark(GlobalUtil.convertToString(obj[i++]));
            deliveryDTO.setContactPhone(GlobalUtil.convertToString(obj[i++]));
            deliveryDTO.setContactName(GlobalUtil.convertToString(obj[i++]));
            returnList.add(deliveryDTO);
        }
        return returnList;
    }
}
