package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.GlobalFeature;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GlobalFeatureRepo extends JpaRepository<GlobalFeature, Long>,GlobalFeatureCustomRepo {
    List<GlobalFeature> findByCategoryId(Long categoryId);
    List<GlobalFeature> findAllByCategoryIdIn(List<Long>IdList);
}
