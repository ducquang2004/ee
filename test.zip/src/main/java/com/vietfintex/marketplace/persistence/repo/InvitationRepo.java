package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.persistence.model.Invitation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.lang.Nullable;

import java.util.List;

public interface InvitationRepo extends JpaRepository<Invitation,Long>, InvitationCustomRepo {
    List<Invitation> getByUserIdAndStatus(Long userId,@Nullable String status);
    Invitation getByUserIdAndGroupId(Long userId, Long groupId);
}
