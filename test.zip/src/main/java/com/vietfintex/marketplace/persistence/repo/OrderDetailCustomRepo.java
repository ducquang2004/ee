package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.web.dto.OrderDetailDTO;
import com.vietfintex.marketplace.web.dto.OrderDetailWrapDTO;

import java.util.List;
public interface OrderDetailCustomRepo {
    List<OrderDetailDTO> search(OrderDetailDTO searchDTO, int startPage, int pageSize);
    List<OrderDetailWrapDTO> getOrderByUserId(Long userId,Long deliveryStatus, int startPage, Long productOwnerId);
    Long count(OrderDetailDTO searchDTO);
    OrderDetailDTO completeOrder(OrderDetailDTO orderDetailDTO);
}
