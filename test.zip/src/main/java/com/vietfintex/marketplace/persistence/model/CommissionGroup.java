package com.vietfintex.marketplace.persistence.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "commission_group")
public class CommissionGroup implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "commission_group_id")
    private Long commissionGroupId;
    @Column(name = "group_id")
    private Long groupId;
    @Column(name = "owner_group_percent")
    private Double ownerGroupPercent;
    @Column(name = "parent_buyer_percent")
    private Double parentBuyerPercent;
    @Column(name = "buyer_percent")
    private Double buyerPercent;
    @Column(name = "smile_tech_percent")
    private Double smileTechPercent;

    public Long getCommissionGroupId() {
        return commissionGroupId;
    }

    public void setCommissionGroupId(Long commissionGroupId) {
        this.commissionGroupId = commissionGroupId;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public Double getOwnerGroupPercent() {
        return ownerGroupPercent;
    }

    public void setOwnerGroupPercent(Double ownerGroupPercent) {
        this.ownerGroupPercent = ownerGroupPercent;
    }

    public Double getParentBuyerPercent() {
        return parentBuyerPercent;
    }

    public void setParentBuyerPercent(Double parentBuyerPercent) {
        this.parentBuyerPercent = parentBuyerPercent;
    }

    public Double getBuyerPercent() {
        return buyerPercent;
    }

    public void setBuyerPercent(Double buyerPercent) {
        this.buyerPercent = buyerPercent;
    }

    public Double getSmileTechPercent() {
        return smileTechPercent;
    }

    public void setSmileTechPercent(Double smileTechPercent) {
        this.smileTechPercent = smileTechPercent;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CommissionGroup)) {
            return false;
        }
        CommissionGroup other = (CommissionGroup) object;
        if (this.commissionGroupId == null && other.commissionGroupId != null) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.vietfintex.marketplace.model.CommissionGroup[ commissionGroupId=" + commissionGroupId + " ]";
    }

}
