package com.vietfintex.marketplace.persistence.repo;

import com.vietfintex.marketplace.web.dto.GroupPostDTO;
import com.vietfintex.marketplace.web.dto.GroupPostWrapDTO;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface GroupPostCustomRepo {
    List<GroupPostWrapDTO> search(GroupPostDTO searchDTO, Pageable pageable);
}
