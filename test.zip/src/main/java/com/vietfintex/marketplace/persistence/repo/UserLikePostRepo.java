package com.vietfintex.marketplace.persistence.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vietfintex.marketplace.persistence.model.UserLikePost;

public interface UserLikePostRepo extends JpaRepository<UserLikePost,Long> {
	List<UserLikePost> findAllByObjectTypeAndObjectIdAndUserId(String objectType,Long postId,Long userId);
}
