package com.vietfintex.marketplace.persistence.repo.impl;
import com.vietfintex.marketplace.persistence.repo.GroupPostCustomRepo;
import com.vietfintex.marketplace.util.GlobalUtil;
import com.vietfintex.marketplace.util.NumberUtils;
import com.vietfintex.marketplace.web.dto.*;
import org.springframework.data.domain.Pageable;

import javax.persistence.EntityManager;
import javax.persistence.OrderBy;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static java.util.Objects.isNull;

public class GroupPostRepoImpl implements GroupPostCustomRepo {
    @PersistenceContext
    private EntityManager em;


    @Override
    @OrderBy("start_date")
    public List<GroupPostWrapDTO> search(GroupPostDTO searchDTO, Pageable pageable) {
        HashMap<String,Object> param = new HashMap<>();
        String sql = "";
        //Tim theo product
         sql = "SELECT gp.owner_id, gp.product_id, gp.store_id, gp.category_store_id, gp.discount_percent,  "
                + "  gp.discount_price, gp.expired_date, gp.start_date,gp.group_id, gp.group_post_id, gp.is_active,gp.full_description,gp.post_type, p.store_id as PStoreId, "
                + " p.full_description pFullDescription, p.list_price pListPrice, p.price pPrice, p.product_code pProduct, "
                + " p.product_name pProductName,p.product_id pProductId, "
                + " null as sStoreId,null sAddress,null sStatus, null storeDescription,null storeName, null categoryName "
                + " , null cCategoryId ,null aliasName "
                + " FROM group_post gp INNER JOIN product p ON gp.product_id = p.product_id WHERE 1 = 1 ";
        if (searchDTO.getOwnerId() != null) {
            sql += " AND gp.owner_id =:ownerId  ";
            param.put("ownerId", searchDTO.getOwnerId());
        }
        if (searchDTO.getProductId() != null) {
            sql += " AND gp.product_id =:productId  ";
            param.put("productId", searchDTO.getProductId());
        }
        if (searchDTO.getGroupId() != null) {
            sql += " AND gp.group_id =:groupId ";
            param.put("groupId", searchDTO.getGroupId());
        }
        if (searchDTO.getGroupPostId() != null) {
            sql += " AND gp.group_post_id =:groupPostId";
            param.put("groupPostId", searchDTO.getGroupPostId());
        }
        if (searchDTO.getIsActive() != null) {
            sql += " AND gp.is_active =:isActive";
            param.put("isActive", searchDTO.getIsActive());
        }
        if (searchDTO.getPostType() != null) {
            sql += " AND gp.post_type =:postType";
            param.put("postType", searchDTO.getPostType());
        }
        //Tim theo store

        sql += " UNION SELECT gp.owner_id, gp.product_id, gp.store_id, gp.category_store_id, gp.discount_percent,  "
                + " gp.discount_price,gp.expired_date, gp.start_date,gp.group_id, gp.group_post_id, gp.is_active,gp.full_description,gp.post_type,null as PStoreId, "
                + " null pFullDescription, null pListPrice, null pPrice, null pProduct, "
                + " null pProductName ,null pProductId, s.store_id sStoreId,s.address sAddress,s.status sStatus, "
                + " s.store_description storeDescription,s.store_name storeName, null categoryName "
                + " , null cCategoryId ,null aliasName "
                + " FROM group_post gp INNER JOIN store s ON gp.store_id = s.store_id WHERE 1 = 1 ";
        if (searchDTO.getOwnerId() != null) {
            sql += " AND gp.owner_id =:ownerId  ";
        }
        if (searchDTO.getStoreId() != null) {
            sql += " AND gp.store_id =:storeId  ";
            param.put("storeId", searchDTO.getStoreId());
        }
        if (searchDTO.getGroupId() != null) {
            sql += " AND gp.group_id =:groupId ";
        }
        if (searchDTO.getGroupPostId() != null) {
            sql += " AND gp.group_post_id =:groupPostId";
        }
        if (searchDTO.getIsActive() != null) {
            sql += " AND gp.is_active =:isActive";
            param.put("isActive", searchDTO.getIsActive());
        }
        if (searchDTO.getPostType() != null) {
            sql += " AND gp.post_type =:postType";
            param.put("postType", searchDTO.getPostType());
        }
        //Tim theo store category
        sql += " UNION SELECT gp.owner_id, gp.product_id, gp.store_id, gp.category_store_id, gp.discount_percent,  "
                + " gp.discount_price,gp.expired_date, gp.start_date,gp.group_id, gp.group_post_id, gp.is_active,gp.full_description,gp.post_type, null as PStoreId,  "
                + " null pFullDescription, null pListPrice, null pPrice, null pProduct, "
                + " null pProductName ,null pProductId, s.store_id sStoreId,s.address sAddress,s.status sStatus, "
                + " s.store_description storeDescription,s.store_name storeName, c.category_name categoryName "
                + " , c.category_id cCategoryId, c.alias_name aliasName "
                + " FROM store_category sc INNER JOIN  group_post gp ON gp.category_store_id = sc.store_category_id "
                + " INNER JOIN store s ON sc.store_id = s.store_id INNER JOIN category c ON sc.category_id = c.category_id WHERE 1 = 1";
        if (searchDTO.getOwnerId() != null) {
            sql += " AND gp.owner_id =:ownerId  ";
        }
        if (searchDTO.getCategoryStoreId() != null) {
            sql += " AND gp.category_store_id =:categoryStoreId  ";
            param.put("categoryStoreId", searchDTO.getCategoryStoreId());
        }
        if (searchDTO.getGroupId() != null) {
            sql += " AND gp.group_id =:groupId ";
        }
        if (searchDTO.getGroupPostId() != null) {
            sql += " AND gp.group_post_id =:groupPostId";
        }
        if (searchDTO.getIsActive() != null) {
            sql += " AND gp.is_active =:isActive";
            param.put("isActive", searchDTO.getIsActive());
        }
        if (searchDTO.getPostType() != null) {
            sql += " AND gp.post_type =:postType";
            param.put("postType", searchDTO.getPostType());
        }
        Query query = em.createNativeQuery(sql);
        param.forEach(query::setParameter);
        query.setFirstResult(pageable.getPageNumber());
        query.setMaxResults(pageable.getPageSize());

        List<Object[]> lst = query.getResultList();
        List<GroupPostWrapDTO> returnList = new ArrayList<>();
        if(isNull(lst)){
            return null;
        }
        int i;
        for (Object[] obj: lst) {
            i = 0;
            GroupPostWrapDTO groupPostWrapDTO = new GroupPostWrapDTO();
            GroupPostDTO groupPostDTO = new GroupPostDTO();
            ProductDTO productDTO = new ProductDTO();
            StoreDTO storeDTO = new StoreDTO();
            StoreCategoryDTO storeCategoryDTO = new StoreCategoryDTO();
            //set groupPost
            groupPostDTO.setOwnerId(obj[i]== null? null:NumberUtils.convertToLong(obj[i])); i++;
            groupPostDTO.setProductId(obj[i]== null? null:NumberUtils.convertToLong(obj[i])); i++;
            groupPostDTO.setStoreId(obj[i]== null? null:NumberUtils.convertToLong(obj[i])); i++;
            groupPostDTO.setCategoryStoreId(obj[i]== null? null:NumberUtils.convertToLong(obj[i])); i++;
            groupPostDTO.setDiscountPercent(obj[i]== null? null:NumberUtils.convertToInt(obj[i])); i++;
            groupPostDTO.setDiscountPrice(obj[i]== null? null:NumberUtils.convertToDouble(obj[i])); i++;
            groupPostDTO.setExpiredDate(obj[i]== null? null:GlobalUtil.convertObjectToDate(obj[i])); i++;
            groupPostDTO.setStartDate(obj[i]== null? null:GlobalUtil.convertObjectToDate(obj[i])); i++;
            groupPostDTO.setGroupId(obj[i]== null? null:NumberUtils.convertToLong(obj[i])); i++;
            groupPostDTO.setGroupPostId(obj[i]== null? null:NumberUtils.convertToLong(obj[i])); i++;
            groupPostDTO.setIsActive(obj[i]== null? null:NumberUtils.convertToInt(obj[i])); i++;
            groupPostDTO.setFullDescription(obj[i]== null? null:GlobalUtil.convertToString(obj[i])); i++;
            groupPostDTO.setPostType(obj[i]== null? null:GlobalUtil.convertToString(obj[i])); i++;
            groupPostWrapDTO.setGroupPostDTO(groupPostDTO);
            //Set Product
            productDTO.setStoreId(obj[i]== null? null:NumberUtils.convertToLong(obj[i])); i++;
            productDTO.setFullDescription(obj[i]== null? null:GlobalUtil.convertToString(obj[i])); i++;
            productDTO.setListPrice(obj[i]== null? null:NumberUtils.convertToDouble(obj[i])); i++;
            productDTO.setPrice(obj[i]== null? null:NumberUtils.convertToDouble(obj[i])); i++;
            productDTO.setProductCode(obj[i]== null? null:GlobalUtil.convertToString(obj[i])); i++;
            productDTO.setProductName(obj[i]== null? null:GlobalUtil.convertToString(obj[i])); i++;
            productDTO.setProductId(obj[i]== null? null:NumberUtils.convertToLong(obj[i])); i++;
            groupPostWrapDTO.setProductDTO(productDTO);
            //Set Store
            storeDTO.setStoreId(NumberUtils.convertToLong(obj[i]== null? null:obj[i])); i++;
            storeDTO.setAddress(GlobalUtil.convertToString(obj[i]== null? null:obj[i])); i++;
            storeDTO.setStatus(GlobalUtil.convertToString(obj[i]== null? null:obj[i])); i++;
            storeDTO.setStoreDescription(GlobalUtil.convertToString(obj[i]== null? null:obj[i])); i++;
            storeDTO.setStoreName(GlobalUtil.convertToString(obj[i]== null? null:obj[i])); i++;
            groupPostWrapDTO.setStoreDTO(storeDTO);
            //Set store category
            storeCategoryDTO.setCategoryName(obj[i]== null? null:GlobalUtil.convertToString(obj[i])); i++;
            storeCategoryDTO.setCategoryId(obj[i]== null? null:NumberUtils.convertToLong(obj[i])); i++;
            storeCategoryDTO.setAlias(obj[i]== null? null:GlobalUtil.convertToString(obj[i])); i++;
            groupPostWrapDTO.setStoreCategoryDTO(storeCategoryDTO);

            returnList.add(groupPostWrapDTO);
        }
        return returnList;
    }
}
