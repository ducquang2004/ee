package com.vietfintex.marketplace.persistence.repo;

public interface UserProfileCustomRepo {
}
